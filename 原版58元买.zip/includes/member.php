<?php
if(!defined('IN_CRONLITE'))exit();
$clientip=real_ip($conf['ip_type']?$conf['ip_type']:0);

if(isset($_COOKIE["admin_token"]))
{
	$token=authcode(daddslashes($_COOKIE['admin_token']), 'DECODE', SYS_KEY);
	list($admintypeid, $user, $sid) = explode("\t", $token);
	if($admintypeid == '1'){
		if($adminuserrow = $DB->getRow("SELECT * FROM pre_account WHERE id='".intval($user)."' LIMIT 1")){
			$session=md5($adminuserrow['username'].$adminuserrow['password'].$password_hash);
			if($session===$sid && $adminuserrow['active']==1) {
				$islogin=1;
			}
		}
	}else{
		$session=md5($conf['admin_user'].$conf['admin_pwd'].$password_hash);
		if($session===$sid) {
			$islogin=1;
		}
	}
}

if (strpos($_SERVER["PHP_SELF"], "/set.php") != false) {
    if ($islogin != 1) @header("Location: ./login.php");
} //防止彩虹狗免密进set.php

if(isset($_COOKIE["user_token"]))
{
	$token=authcode(daddslashes($_COOKIE['user_token']), 'DECODE', SYS_KEY);
	list($zid, $sid) = explode("\t", $token);
	if($userrow = $DB->getRow("SELECT * FROM pre_site WHERE zid='".intval($zid)."' LIMIT 1")){
		$session=md5($userrow['user'].$userrow['pwd'].$password_hash);
		if($session===$sid && $userrow['status']==1) {
			$islogin2=1;
		}
	}
}

/** 授权系统对接 */
			$zbape              = 'http://auth.lianxuncloud.com/api/index/';
			$api                = 'recommend?appid=3&webkey=AnDi_Auth_1969215';
			$zbapi              = $zbape . $api;
			$zbape = curl_init();
			curl_setopt($zbape,CURLOPT_URL,"{$zbapi}");
			curl_setopt($zbape, CURLOPT_SSL_VERIFYPEER, false); //如果USBURL就是https的,我们将其设为不验证,如果不是https的接口,这句可以不必加
			curl_setopt($zbape,CURLOPT_RETURNTRANSFER,true);
			curl_setopt($zbape, CURLOPT_NOSIGNAL, true);
// 			curl_setopt($zbape, CURLOPT_CONNECTTIMEOUT_MS, 500);
// 			curl_setopt($zbape, CURLOPT_TIMEOUT_MS, 500);
			$data = curl_exec($zbape);
			curl_close($zbape);
			$data=json_decode($data,true);//将json格式转化为数组格式,方便使用
			if(is_array($data)){
				foreach($data as $key => $value)
					$key = $value;
//看这个获取需要获取的数据
				$name = $value[0]["webname"];  //名称
				$qq = $value[0]["webqq"];  //QQ号
				$money = $value[0]["money"];  //价格
			}
?>