<?php
//防CC模块设置
define('CC_Defender', 1);
?>