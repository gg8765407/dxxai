<?php
$nosession = true;
include("../../includes/common.php");
$act=isset($_GET['act'])?daddslashes($_GET['act']):null;
@header('Content-Type: text/html; charset=UTF-8');
if(!checkRefererHost())exit('{"code":403}');
if($act=='tuidan'){
	$id = intval($_POST['id']);
	if(md5($id.SYS_KEY.$id)!==$_POST['skey'])exit('{"code":-1,"msg":"验证失败"}');
	$row=$DB->getRow("SELECT * FROM pre_orders WHERE id='$id' LIMIT 1");
	if($row){
		if($row['status'] =='2' || $row['status'] =='3'){
			
		}else{
			exit('只允许【正在处理、异常】的订单退款');
		}
	}else{
		exit('当前订单不存在！');
	}
	
	$tool=$DB->getRow("SELECT * FROM pre_tools WHERE tid='{$row['tid']}' LIMIT 1");
	$shequ=$DB->getRow("SELECT * FROM pre_shequ WHERE id='{$tool['shequ']}' LIMIT 1");
	$url = ($shequ['protocol']==1?'https://':'http://') . $shequ['url'];
	
	if($shequ['type'] == 'jiuwu'){
		
		$data = jiuwu_tuidan($url,$shequ['username'],$shequ['password'],$row['djorder'],$tool['goods_id']);
		$data = json_decode($data,true);
		if($data['status'] == '1'){
			exit($data['info']);
		}else{
			exit($data['info'].'<br><br>温馨提示：可能该商品不支持自助申请退单 或 已经申请！');
		}
		
	}elseif($shequ['type'] == 'yile'){
		
		$url = $url.'./api/order/action';
		$param = array('api_token'=>$shequ['username'], 'timestamp'=>time(), 'id'=>$row['djorder'], 'status'=>'2');
		$sign = yile_getSign($param,$shequ['password']);
		$param['sign'] = $sign;
		$post = http_build_query($param);
		$ret = get_curl($url,$post);
		$data = json_decode($ret,true);
		$ret = $data['message'];
		exit($ret);
		
	}elseif($shequ['type'] == 'daishua'){
		$user = $shequ['username'];
		$pass = $shequ['password'];
		$url = $url.'/api_tool/api/api.php?act=dsw_tuidan';
		$post = 'user='.$user.'&pass='.$pass.'&id='.$row['djorder'];
		$ret = get_curl($url,$post);
		exit($ret);
		
	}else{
		exit('目前，仅支持同系统、玖五、亿乐主动向供货商申请退单<br>注意：部分商品是不能申请成功的');
	}
	
	
}else{
	$result=array("code"=>-5,"msg"=>"No Act!");
}


echo json_encode($result);
$DB->close();
function jiuwu_tuidan($url,$user,$paw,$order_id,$goods_type){
	@header('Content-Type: application/json; charset=UTF-8');
	$cookie = isset($_SESSION["api_cookie"]) ? base64_decode($_SESSION["api_cookie"]) : NULL;
	$i = 1;
	if(!$cookie){
		do{
			if(!($cookie = jiuwu_login($url,$user,$paw))){
				$i++;
			}else{
				break;
			}
		}while ($i<=2);
		if($i == 2){exit('{"code":-1,"msg":"尝试登录'.$i.'次还是失败哦！请确保账号密码是否正确！"}');}		
	}
	$post = 'action=tuidan&goods_type='.$goods_type.'&order_id='.$order_id;
	$url = $url.'/index.php?m=home&c=order&a=order_action';
	$data = jiuwu_a_get_curl($url,$post,$cookie,1,1);
	//{"info":"\u6ca1\u6709\u627e\u5230\u8ba2\u5355\u6216\u8be5\u8ba2\u5355\u4e0d\u7b26\u5408\u64cd\u4f5c\u6761\u4ef6\uff01","status":0,"url":""} 失败
	//{"info":"\u9000\u5355\u7533\u8bf7\u6210\u529f,\u8bf7\u7b49\u5019\u7cfb\u7edf\u7ba1\u7406\u5458\u5904\u7406\uff01","status":1,"url":""} 申请退单成功
	$data = '{"'.getSubstr($data,'{"','"}').'"}';
	return $data;
}
function jiuwu_login($url,$user,$pwd){
	$get = get_curl_tuidan($url.'/index.php?m=Home&c=User&a=login', 'username='.urlencode($user).'&username_password='.urlencode($pwd), 0, 0, 1);
	if (strpos($get, "登录成功")) {
		if (preg_match_all('/Set-Cookie:\s?([A-Za-z0-9\_=\|]+);/is', $get, $arr2)) {
			$cookie = null;
			foreach ($arr2['1'] as $item) {
				$cookie .= $item . ';';
			}
			$cookie_s = base64_encode($cookie);
			$_SESSION['api_cookie']=$cookie_s;
			return $cookie;
		}
	}
	return false;
}
function get_curl_tuidan($path,$post=0,$referer=0,$cookie=0,$header=0,$addheader=0){
	return shequ_get_curl($path,$post,$referer,$cookie,$header,$addheader);
}
function jiuwu_a_get_curl($url,$post=0,$cookie=0,$header=0,$header1=0){
	$ch = curl_init();
	$url_arr = parse_url($url);//分割提交过来的URL{"scheme":"http","host":"www.longtousq.cn","path":"\/index.php","query":"m=Home&c=User&a=login"}
	//$url = str_replace("http://" . $url_arr["host"] . "/", "http://181.41.215.87/", $url);//替换社区网址
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	$httpheader[] = "Accept: */*";
	$httpheader[] = "Accept-Encoding: gzip,deflate,sdch";
	$httpheader[] = "Accept-Language: zh-CN,zh;q=0.8";
	$httpheader[] = "Connection: close";
	$httpheader[] = "Host: ".$url_arr["host"];
	
	if($header1) {
		$httpheader[] = "X-Requested-With: XMLHttpRequest";
	}
	curl_setopt($ch, CURLOPT_TIMEOUT, 30);
	if ($post) {
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
	}
	curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
	if ($header) {
		curl_setopt($ch, CURLOPT_HEADER, true);
	}
	if($cookie){
		curl_setopt($ch,CURLOPT_COOKIE,$cookie);
	}
	curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36");
	curl_setopt($ch, CURLOPT_ENCODING, "gzip");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$ch_data  = curl_exec($ch);
	curl_close($ch);
	return $ch_data;
}
?>