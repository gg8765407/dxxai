<?php
$nosession = true;
include("../../includes/common.php");
$act=isset($_GET['act'])?daddslashes($_GET['act']):null;
@header('Content-Type: application/json; charset=UTF-8');
if($act=='updateOrder2'){	//单条订单数据更新
	if(isset($_POST['user']) && isset($_POST['key'])){
		if(empty($conf['cronkey']))exit("请先设置好监控密钥");
		if($conf['cronkey']!=$_POST['key'])exit("监控密钥不正确");
		$user = trim(daddslashes($_POST['user']));
		if($user != $conf['admin_user']){
			exit('{"code":-1,"msg":"账号错误"}');
		}
	}else{
		exit('{"code":-1,"msg":"参数账号密码不能为空"}');
	}
	$id = intval($_POST['id']);
	$status=isset($_POST['status'])?daddslashes($_POST['status']):'2';
	$start_num=isset($_POST['start_num'])?daddslashes($_POST['start_num']):'0';
	$now_num=isset($_POST['now_num'])?daddslashes($_POST['now_num']):'0';
	if($id == 0)exit('{"code":-1,"msg":"订单号错误"}');
	$row = $DB->getRow("SELECT * FROM `pre_orders` WHERE `id` = '{$id}' LIMIT 1");
	if($row){
		if($status == '99'){
			$status = '3';
			$djstate = '等待退款';
		}else{
			$djstate = '';
		}
		$uptime = time();
		if($DB->exec("UPDATE pre_orders SET status='{$status}', xbc_start_num='{$start_num}', xbc_now_num='{$now_num}', xbc_djstate='{$djstate}', uptime='{$uptime}' WHERE id='{$id}' LIMIT 1")){
			exit('{"code":1,"msg":"更新成功"}');
		}else{
			exit('{"code":-1,"msg":"更新失败'.$DB->error().'"}');
		}
	}else{
		exit('{"code":-1,"msg":"订单号不存在"}');
	}
}elseif($act=='updateOrder'){	//订单数据更新
	if(isset($_POST['user']) && isset($_POST['key'])){
		if(empty($conf['cronkey']))exit("请先设置好监控密钥");
		if($conf['cronkey']!=$_POST['key'])exit("监控密钥不正确");
		$user = trim(daddslashes($_POST['user']));
		if($user != $conf['admin_user']){
			exit('{"code":-1,"msg":"账号错误"}');
		}
	}else{
		exit('{"code":-1,"msg":"参数账号密码不能为空"}');
	}
	$list = $_POST['list'];
	if($list == '')exit('{"code":-1,"msg":"json文本不能为空"}');
	$json = json_decode($list,true);
	if(!is_array($json))exit('{"code":-1,"msg":"json文本格式不正确"}');
	if(count($json)==0)exit('{"code":-1,"msg":"数据不能为空"}');
	if($json[0]['id'] == '' || $json[0]['id'] == null){
		exit('{"code":-1,"msg":"json文本格式不正确"}');
	}
	$dsw_id = array();
	$status = array();
	$start_num = array();
	$now_num = array();
	$djstate = array();
	//0 待处理,1 已完成,2 正在处理,3 异常
	foreach ($json as $value) {
		if($value['status'] == 99){	//标记 把钱退给用户
			$status[] = "WHEN ".$value['id']." THEN '3'";
			$djstate[] = "WHEN ".$value['id']." THEN '等待退款'";
		}else{
			$status[] = "WHEN ".$value['id']." THEN '".$value['status']."'";
			$djstate[] = "WHEN ".$value['id']." THEN ''";
		}
		$start_num[] = "WHEN ".$value['id']." THEN '".$value['start_num']."'";
		$now_num[] = "WHEN ".$value['id']." THEN '".$value['now_num']."'";
		$dsw_id[] = $value['id'];
	}
	if(!empty($dsw_id)){
		$sql = "
		UPDATE pre_orders 
			SET status = CASE id 
				".implode(' ',$status)."
			END, 
			xbc_start_num = CASE id 
				".implode(' ',$start_num)."
			END, 
			xbc_now_num = CASE id 
				".implode(' ',$now_num)."
			END, 
			xbc_djstate = CASE id 
				".implode(' ',$djstate)."
			END
		WHERE id IN (".implode(',',$dsw_id).")
		";
		if($DB->exec($sql)){
			exit('{"code":1,"msg":"更新成功"}');
		}else{
			exit('{"code":-1,"msg":"更新失败'.$DB->error().'"}');
		}
	}else{
		exit('{"code":-1,"msg":"没有数据需要更新的"}');
	}

}elseif($act=='getOrderList'){	//订单下载
	if(isset($_POST['user']) && isset($_POST['key'])){
		if(empty($conf['cronkey']))exit("请先设置好监控密钥");
		if($conf['cronkey']!=$_POST['key'])exit("监控密钥不正确");
		$user = trim(daddslashes($_POST['user']));
		if($user != $conf['admin_user']){
			exit('{"code":-1,"msg":"账号错误"}');
		}
	}else{
		exit('{"code":-1,"msg":"参数账号密码不能为空"}');
	}	
	$tid = trim(daddslashes($_POST['tid']));
	$status=isset($_POST['status'])?daddslashes($_POST['status']):'0';
	$type=isset($_POST['type'])?daddslashes($_POST['type']):'0';
	$limit=isset($_POST['limit'])?daddslashes($_POST['limit']):'1000';
	if(!empty($tid)){	//empty 变量为空 返回 true   
		$sql = " a.tid in(".$tid.")";
	}else{
		exit('{"code":-1,"msg":"商品ID不能为空"}');
	}
	$re=$DB->query("SELECT a.*,b.name FROM pre_orders a LEFT JOIN pre_tools b ON a.tid=b.tid WHERE{$sql} AND a.status in({$status}) AND b.is_curl='{$type}' ORDER BY a.id DESC LIMIT ".$limit);
	$data = array();
	$total = 0;
	while($res = $re->fetch()){
		$data[]=array(
			'id'=>$res['id'],
			'tid'=>$res['tid'],
			'name'=>$res['name'],
			'status'=>$res['status'],
			'money'=>$res['money'],
			'input'=>$res['input'],
			'input2'=>$res['input2'],
			'input3'=>$res['input3'],
			'input4'=>$res['input4'],
			'input5'=>$res['input5'],
			'start_num'=>$res['xbc_start_num'],
			'now_num'=>$res['xbc_now_num'],
			'end_num'=>$res['xbc_end_num'],
			'addtime'=>$res['addtime']
		);
		$total++;
	}
    if(count($data)==0){
    	$result=array("code"=>-1,"msg"=>"获取失败","data"=>null);
    }else{
    	$result=array("code"=>1,"msg"=>"获取成功","total"=>$total,"data"=>$data);
    }
    exit(json_encode($result));

}elseif($act=='getGoodsDesc'){	//批量获取商品介绍
	if(isset($_POST['user']) && isset($_POST['pass'])){
		$user = trim(daddslashes($_POST['user']));
		$pass = trim(daddslashes($_POST['pass']));
		$userrow = $DB->getRow("SELECT * FROM `pre_site` WHERE `user` = '{$user}' LIMIT 1");
		if ($userrow && $userrow['user'] == $user && $userrow['pwd'] == $pass && $userrow['status'] == 1) {

		} elseif ($userrow && $userrow['status'] == 0) {
			exit('{"code":-1,"msg":"该账户已被封禁"}');
		} else {
			exit('{"code":-1,"msg":"用户名或密码不正确"}');
		}
	}else{
		exit('{"code":-1,"msg":"参数账号密码不能为空"}');
	}
	$re=$DB->query("SELECT * FROM pre_tools WHERE active='1' ORDER BY sort ASC");	//商品列表
	$data = array();
	$total = 0;
	while($res = $re->fetch()){
		$data[]=array('tid'=>$res['tid'],'desc'=>$res['desc']);
		$total++;
		$i++;
	}
    if(count($data)==0){
    	$result=array("code"=>-1,"msg"=>"获取失败","data"=>$data);
    }else{
    	$result=array("code"=>1,"msg"=>"获取成功","total"=>$i,"data"=>$data);
    }
    exit(json_encode($result));

}elseif($act=='getGoodsLiti'){	//批量获取对接数据
	if(isset($_POST['user']) && isset($_POST['pass'])){
		$user = trim(daddslashes($_POST['user']));
		$pass = trim(daddslashes($_POST['pass']));
		$userrow = $DB->getRow("SELECT * FROM `pre_site` WHERE `user` = '{$user}' LIMIT 1");
		if ($userrow && $userrow['user'] == $user && $userrow['pwd'] == $pass && $userrow['status'] == 1) {
			$islogin2 = 1;
			$price_obj = new \lib\Price($userrow['zid'],$userrow);
		} elseif ($userrow && $userrow['status'] == 0) {
			exit('{"code":-1,"msg":"该账户已被封禁"}');
		} else {
			exit('{"code":-1,"msg":"用户名或密码不正确"}');
		}
	}else{
		exit('{"code":-1,"msg":"参数账号密码不能为空"}');
	}
    $re=$DB->query("SELECT * FROM pre_class_one  WHERE active='1' ORDER BY sort ASC");
    $i=0;
    $list = array();
    while($res = $re->fetch()){	//一级目录
    	$one_name = $res['name'];
    	$re2=$DB->query("SELECT * FROM pre_class WHERE active='1' AND oneid='{$res['cid']}' ORDER BY sort ASC");	//二级目录
    	$two_list = array();
    	while($res2 = $re2->fetch()){
			$re3=$DB->query("SELECT * FROM pre_tools WHERE active='1' AND cid='{$res2['cid']}' ORDER BY sort ASC");	//商品列表
			$data = array();
			$total = 0;
	    	while($res3 = $re3->fetch()){
				if(isset($price_obj)){
					$price_obj->setToolInfo($res3['tid'],$res3);
					$price=$price_obj->getToolPrice($res3['tid']);
				}else $price=$res3['price'];
				if($res3['is_curl']==4){
					$isfaka = 1;
					$res3['input'] = getFakaInput();
				}else{
					$isfaka = 0;
				}
				//,'desc'=>$res3['desc']
				$data[]=array('tid'=>$res3['tid'],'cid'=>$res3['cid'],'sort'=>$res3['sort'],'name'=>$res3['name'],'value'=>$res3['value'],'price'=>$price,'input'=>$res3['input'],'inputs'=>$res3['inputs'],'alert'=>$res3['alert'],'shopimg'=>$res3['shopimg'],'validate'=>$res3['validate'],'valiserv'=>$res3['valiserv'],'repeat'=>$res3['repeat'],'multi'=>$res3['multi'],'close'=>$res3['close'],'active'=>$res3['active'],'prices'=>$res3['prices'],'min'=>$res3['min'],'max'=>$res3['max'],'sales'=>$res3['sales'],'isfaka'=>$isfaka,'stock'=>$res3['stock']);
				$total++;
				$i++;
	    	}
	    	$two_list[] = array('two_name' => $res2['name'], 'shopimg' => $res2['shopimg'], 'total' => $total, 'data' => $data);
    	}
    	$list[] = array('one_name' => $one_name, 'shopimg' => $res['shopimg'], 'two' => $two_list);
    }
    if(count($list)==0){
    	$result=array("code"=>-1,"msg"=>"获取失败","data"=>$list);
    }else{
    	$result=array("code"=>1,"msg"=>"获取成功","total"=>$i,"data"=>$list);
    }
    exit(json_encode($result));

}elseif($act=='pricejk'){//单独监控亿乐社区
	if(empty($conf['cronkey']))exit("请先设置好监控密钥");
	if($conf['cronkey']!=$_GET['key'])exit("监控密钥不正确");	
	$cron_lasttime = getSetting('pricejk_lasttime', true);
	$pricejk_time = $conf['pricejk_time']?$conf['pricejk_time']-50:50;
	if(!isset($_GET['test']) && time()-strtotime($cron_lasttime)<$pricejk_time)exit('上次更新时间:'.$cron_lasttime);
	saveSetting('pricejk_lasttime',$date);
	$success = 0;
	$is_need = 0;
	$conf['pricejk_yile']=1;
	$rs=$DB->query("SELECT * FROM pre_shequ WHERE type='yile' ORDER BY id ASC");
	while($res = $rs->fetch())
	{
		$tcount = $DB->getColumn("SELECT count(*) FROM pre_tools WHERE is_curl=2 AND shequ='{$res['id']}' AND cid IN ({$conf['pricejk_cid']}) AND active=1");
		if($tcount>0 && $res['username'] && $res['password'] && $res['type']){
			$is_need++;
			$results = third_call($res['type'], $res, 'pricejk', [$res['id'], &$success]);
			if($results === false) continue;
			if($results===true){
				saveSetting('pricejk_status','ok');
			}else{
				saveSetting('pricejk_status',$results);
				echo '对接站点ID'.$res['id'].'：'.$results.'<br/>';
			}
		}
	}
	if($is_need==0){
		exit('没有需要监控价格的商品');
	}else{
		exit('成功更新'.$success.'个商品的价格');
	}	

}elseif($act=='getdd'){
	
	if(isset($_GET['id'])){
		$row = $DB->getRow("SELECT * FROM `pre_orders` where id='{$_GET['id']}' LIMIT 1");
		if($row){
			$imgname = 'okimg/'.md5($row['id'].$row['id']).'.jpg';
			$DB->exec("update pre_orders set result='{$imgname}',status='1',endtime='{$date}' where id='{$_GET['id']}'");
			exit($_GET['id'].' 已完成！');
		}else{
			exit($row."没有该订单号：".$_GET['id']);
		}
		
	}else{
		$row = $DB->getRow("SELECT a.*,b.name,b.input as inputa,b.inputs FROM `pre_orders` a left join `pre_tools` b on a.tid=b.tid where a.status='0' ORDER BY a.addtime ASC LIMIT 1");
		exit(json_encode($row));
	}

	
}elseif($act=='change'){	//商品变动
	if(empty($conf['cronkey']))exit("请先设置好监控密钥");
	if($conf['cronkey']!=$_GET['key'])exit("监控密钥不正确");
	$count=$DB->getColumn("SELECT count(*) FROM pre_goods_change WHERE type='0'");
	if($count == '0'){//初始数据
		$rs = $DB->query("SELECT * FROM pre_tools");
		$data = array();
		$i = 0;
		while($res = $rs->fetch()){
			$i++;
			$data[]="('".$res['tid']."' ,'".$res['name']."' ,'".$res['price']."' ,'".$res['active']."' ,'".$res['close']."' ,'0' ,NOW())";
		}
		$sql = "INSERT INTO pre_goods_change (`tid`,`name`,`price`,`active`,`close`,`type`,`changetime`) values ".implode(',',$data);
		if($DB->exec($sql)){
			exit('成功载入 '.$i.' 条初始数据！');
		}else{
			exit('初始数据失败！');
		}
	}else{//比较数据
		
		//删除调价记录
		$day=isset($_GET['day'])?daddslashes($_GET['day']):'30';
		$DB->exec("DELETE FROM pre_goods_change WHERE changetime<'".date("Y-m-d H:i:s",strtotime("-".$day." days"))."'");
		//获取当前最新的id,最大为2147483647
		$id = $DB->getRow("SELECT id FROM pre_goods_change ORDER BY id DESC LIMIT 1");
		if($id['id'] == '2100000000'){
			//数据数量等于21亿条时，就重置shua_goods_change表
			$DB->exec("truncate table pre_goods_change");
		}
		
		$rs = $DB->query("SELECT * FROM pre_goods_change where type='0'");
		$tid_arr = array();
		$price_arr = array();
		$active_arr = array();//1显示0隐藏
		$close_arr = array();//0上架1下架
		while($res = $rs->fetch()){
			$tid_arr[$res['tid']]=$res['tid'];
			$price_arr[$res['tid']]=$res['price'];
			$active_arr[$res['tid']]=$res['active'];
			$close_arr[$res['tid']]=$res['close'];
		}
		
		$rs2 = $DB->query("SELECT * FROM pre_tools");// LIMIT 5
		$data = array();
		$i = 0;
		$n = 0;
		$m = 0;
		while($res2 = $rs2->fetch()){
			//检测商品是否存在
			if($res2['tid'] == $tid_arr[$res2['tid']]){
				//active 1显示0隐藏
				//close 0上架1下架
				//比较显示隐藏、上下架
				if($active_arr[$res2['tid']] == '1' && $res2['active'] == '0'){
					$srt = '<font color=red>下架</font>';
					$DB->exec("update `pre_goods_change` set `active`='0' ,`close`='{$res2['close']}' ,`price`='{$res2['price']}' ,`changetime`=now() where `tid`='{$res2['tid']}' and `type`='0'");
					$DB->exec("INSERT INTO pre_goods_change (`tid`,`name`,`type`,`alert`,`status`,`changetime`) values('".$res2['tid']."' ,'".$res2['name']."' ,'".$id['id']."' ,'保持不变' ,'".$srt."' ,NOW())");					
					$i++;
					continue;
				}elseif($active_arr[$res2['tid']] == '0' && $res2['active'] == '1'){
					$srt = '<font color=green>销售</font>';
					$DB->exec("update `pre_goods_change` set `active`='1' ,`close`='{$res2['close']}' ,`price`='{$res2['price']}' ,`changetime`=now() where `tid`='{$res2['tid']}' and `type`='0'");
					$DB->exec("INSERT INTO pre_goods_change (`tid`,`name`,`type`,`alert`,`status`,`changetime`) values('".$res2['tid']."' ,'".$res2['name']."' ,'".$id['id']."' ,'保持不变' ,'".$srt."' ,NOW())");					
					$i++;
					continue;
				}else{
					if($close_arr[$res2['tid']] == '0' && $res2['close'] == '1'){
						$i++;
						$srt = '<font color=red>下 架</font>';
						$DB->exec("update `pre_goods_change` set `close`='{$res2['close']}' ,`price`='{$res2['price']}' ,`changetime`=now() where `tid`='{$res2['tid']}' and `type`='0'");
						$DB->exec("INSERT INTO pre_goods_change (`tid`,`name`,`type`,`alert`,`status`,`changetime`) values('".$res2['tid']."' ,'".$res2['name']."' ,'".$id['id']."' ,'保持不变' ,'".$srt."' ,NOW())");
					}elseif($close_arr[$res2['tid']] == '1' && $res2['close'] == '0'){
						$i++;
						$srt = '<font color=green>销 售</font>';
						$DB->exec("update `pre_goods_change` set `close`='{$res2['close']}' ,`price`='{$res2['price']}' ,`changetime`=now() where `tid`='{$res2['tid']}' and `type`='0'");
						$DB->exec("INSERT INTO pre_goods_change (`tid`,`name`,`type`,`alert`,`status`,`changetime`) values('".$res2['tid']."' ,'".$res2['name']."' ,'".$id['id']."' ,'保持不变' ,'".$srt."' ,NOW())");
					}					
				}
				
				//比较价钱
				$aa = '';
 				if($res2['price'] > $price_arr[$res2['tid']]){
					$strprice = round(($res2['price']-$price_arr[$res2['tid']])/$price_arr[$res2['tid']]*100,2).'%';
					$aa = '<font color=red>涨价'.$strprice.'</font>';
				}elseif($res2['price'] < $price_arr[$res2['tid']]){
					$strprice = round(($price_arr[$res2['tid']]-$res2['price'])/$res2['price']*100,2).'%';
					$aa = '<font color=green>降价'.$strprice.'</font>';
				}
				if($aa != ''){
					$count=$DB->getColumn("SELECT count(*) FROM pre_goods_change WHERE type='{$id['id']}' and tid='{$res2['tid']}'");
					if($count=='0'){
						$DB->exec("INSERT INTO pre_goods_change (`tid`,`name`,`type`,`alert`,`status`,`changetime`) values('".$res2['tid']."' ,'".$res2['name']."' ,'".$id['id']."' ,'".$aa."' ,'上架' ,NOW())");
					}else{
						$DB->exec("update `pre_goods_change` set `alert`='{$aa}' ,`price`='{$res2['price']}' ,`changetime`=now() where `tid`='{$res2['tid']}' and `type`='{$id['id']}'");
					}
					$DB->exec("update `pre_goods_change` set `price`='{$res2['price']}' ,`changetime`=now() where `tid`='{$res2['tid']}' and `type`='0'");
					$n++;
				}
				
			}else{
				//不存在就添加 视为新上架
				$data="('".$res2['tid']."' ,'".$res2['name']."' ,'".$res2['price']."' ,'".$res2['active']."' ,'".$res2['close']."' ,'0' ,NOW())";
				$sql = "INSERT INTO pre_goods_change (`tid`,`name`,`price`,`active`,`close`,`type`,`changetime`) values ".$data;
				$DB->exec($sql);
				$m++;
			}
		}//while
	}
	exit('本次有 '.$i.' 条商品状态变动， '.$n.' 商品调价，新上架 '.$m.' 条商品');
}elseif($act=='lqqcx'){	//拉圈圈查询
	
	$user = trim(daddslashes($_POST['user']));
	$pass = trim(daddslashes($_POST['pass']));
	if(!$user)exit('{"code":-1,"msg":"账号不能为空"}');
	if(!$pass)exit('{"code":-1,"msg":"密码不能为空"}');
	$userrow = $DB->getRow("SELECT * FROM `pre_site` WHERE `user` = '{$user}' LIMIT 1");
	if ($userrow && $userrow['user'] == $user && $userrow['pwd'] == $pass && $userrow['status'] == 1) {
		//
	} elseif ($userrow && $userrow['status'] == 0) {
		exit('{"code":-1,"msg":"该账户已被封禁"}');
	} else {
		exit('{"code":-1,"msg":"用户名或密码不正确"}');
	}
	$qq=$_GET['qq'];
	$geturl = ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']. '/';
	$ret = json_decode(get_curl($geturl.'api_tool/lqq/api.php?jk=cx&qq='.$qq),true);
	if($ret['code'] == '1'){
		$ret = $ret['str'];
	}else{
		$ret = '{"code":-1,"msg":"'.$ret['msg'].'"}';
	}
	exit($ret);
	
}elseif($act=='tools'){
	$tid=intval($_GET['tid']);
	if(!$tid)exit('{"code":-1,"msg":"商品ID不能为空"}');
	
	if(isset($_POST['user']) && isset($_POST['pass'])){
		$user = trim(daddslashes($_POST['user']));
		$pass = trim(daddslashes($_POST['pass']));
		$userrow = $DB->getRow("SELECT * FROM `pre_site` WHERE `user` = '{$user}' LIMIT 1");
		if ($userrow && $userrow['user'] == $user && $userrow['pwd'] == $pass && $userrow['status'] == 1) {
			$islogin2 = 1;
			$price_obj = new \lib\Price($userrow['zid'],$userrow);
		} elseif ($userrow && $userrow['status'] == 0) {
			exit('{"code":-1,"msg":"该账户已被封禁"}');
		} else {
			exit('{"code":-1,"msg":"用户名或密码不正确"}');
		}
	}	
	
	
	
	$tool = $DB->getRow("SELECT * FROM `pre_tools` WHERE `tid` = {$tid} LIMIT 1");
	if ($tool && $tool['active'] == 1){
		if($tool['close']==1)exit('{"code":-1,"msg":"当前商品维护中，停止下单！"}');
		
	}
	
	
	if($tool['is_curl']==4){
		$count = $DB->getColumn("SELECT count(*) FROM pre_faka WHERE tid='{$tool['tid']}' AND orderid=0");
		if($count==0)$tool['close']=1;
		$isfaka = 1;
		
		if($count==0)exit('{"code":-1,"msg":"该商品库存卡密不足，请联系站长加卡！"}');
		if($nums>$count)exit('{"code":-1,"msg":"你所购买的数量超过库存数量！"}');
		
	}
	$data = array('tid'=>$tool['tid'],'name'=>$tool['name'],'isfaka'=>$isfaka,'stock'=>$count);
	$result['data'] = $data;
	exit(json_encode($result));

}elseif($act=='cx_lqq'){
	if(!checkRefererHost())exit('{"code":403}');
	$qq = trim(daddslashes($_POST['qq']));
	$geturl = ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']. '/';
	$result = get_curl($geturl.'api_tool/lqq/lqq_api.php?jk=cx&qq='.$qq);
	exit($result);	
	
}elseif($act=='dsw_tuidan'){
	$id=daddslashes($_POST['id']);
	if($id==''){exit('{"code":-1,"msg":"订单id不能为空!"}');}
	if(isset($_POST['user']) && isset($_POST['pass'])){
		$user = trim(daddslashes($_POST['user']));
		$pass = trim(daddslashes($_POST['pass']));
		$userrow = $DB->getRow("SELECT * FROM `pre_site` WHERE `user` = '{$user}' LIMIT 1");
		if($userrow && $userrow['user'] == $user && $userrow['pwd'] == $pass && $userrow['status'] == 1) {
			$zid = $userrow['zid'];
		}elseif ($userrow && $userrow['status'] == 0) {
			exit('{"code":-1,"message":"该账户已被封禁"}');
		}else {
			exit('{"code":-1,"message":"用户名或密码不正确"}');
		}
		
	}
	$row=$DB->getRow("SELECT * FROM pre_orders WHERE id='$id' and zid={$zid} LIMIT 1");
	$id=$row['id'];
	$geturl=($_SERVER['SERVER_PORT']==443 ? 'https://' : 'http://').$_SERVER['HTTP_HOST'].'/';
	$post = 'id='.$id.'&skey='.md5($id.SYS_KEY.$id);
	$ret = get_curl($geturl.'api_tool/api/tuidan.php?act=tuidan',$post,$geturl);
	exit($ret);

}elseif($act=='search'){	//搜索

	
	$id=daddslashes($_POST['id']);
	$status=daddslashes($_POST['status']);
	if($id==''){exit('{"code":-1,"msg":"订单id不能为空，多个请使用,隔开如:1,2,3"}');}
	if($status!=''){$status = ' and status in('.$status.')';}
	if(isset($_POST['user']) && isset($_POST['pass'])){
		$user = trim(daddslashes($_POST['user']));
		$pass = trim(daddslashes($_POST['pass']));
		$userrow = $DB->getRow("SELECT * FROM `pre_site` WHERE `user` = '{$user}' LIMIT 1");
		if($userrow && $userrow['user'] == $user && $userrow['pwd'] == $pass && $userrow['status'] == 1) {
			
		}elseif ($userrow && $userrow['status'] == 0) {
			exit('{"code":-1,"message":"该账户已被封禁"}');
		}else {
			exit('{"code":-1,"message":"用户名或密码不正确"}');
		}
	}	
	$rs=$DB->query("SELECT id,tid,input,status,xbc_start_num,xbc_now_num,endtime FROM pre_orders WHERE id in({$id})$status ORDER BY id desc LIMIT 1000");
	while($res = $rs->fetch()){
		$data[]=array('id'=>$res['id'],'tid'=>$res['tid'],'input'=>$res['input'],'status'=>$res['status'],'xbc_start_num'=>$res['xbc_start_num'],'xbc_now_num'=>$res['xbc_now_num'],'endtime'=>$res['endtime']);
	}
	exit(json_encode($data));

}elseif($act=='getkm'){	//获取卡密
	$tid = $_POST['tid'];
	$id = $_POST['id'];
	$skey = $_POST['skey'];
	if(md5($id.SYS_KEY.$id)!==$skey)exit('{"code":-1,"msg":"验证失败"}');
	$djzt = $DB->getRow("SELECT djzt FROM shua_orders WHERE id ='{$id}' LIMIT 1");
	if($djzt['djzt'] == '3'){
		$rs=$DB->query("SELECT * FROM pre_faka WHERE tid='{$tid}' AND orderid='{$id}' ORDER BY kid ASC");
		
		$kmdata=array();
		$kmstr = '';
		while($res = $rs->fetch()){
			if(!empty($res['pw'])){
				//$kmdata[]=array('card'=>$res['km'],'pass'=>$res['pw']);
				$kmstr.=$res['km'].'----'.$res['pw'].'<br>';
			}else{
				//$kmdata[]=array('card'=>$res['km']);
				$kmstr.=$res['km'].'<br>';
			}
		}
		exit('{"code":1,"msg":"获取成功！","km":"'.$kmstr.'"}');
		//$result['faka']=true;
		//$result['kmdata']=$kmdata;
	}else{
		exit('{"code":-2,"msg":"no!"}');
	}

}else{
	$result=array("code"=>-5,"msg"=>"No Act!");
	exit(json_encode($result));
}
function get_curl_miao($url,$post=0,$referer=0,$cookie=0,$header=0,$ua=0,$nobaody=0){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);       
	$httpheader[] = "Accept: */*";
	$httpheader[] = "Accept-Encoding: gzip,deflate,sdch";
	$httpheader[] = "Accept-Language: zh-CN,zh;q=0.8";
	$httpheader[] = "Connection: close";
	$httpheader[] = "Cache-Control: no-cache";
	$httpheader[] = "Content-Type: application/json;charset=UTF-8";
	curl_setopt($ch, CURLOPT_TIMEOUT, 230);
	if($post){
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		$httpheader[] = "Content-Type: application/x-www-form-urlencoded; charset=UTF-8";
	}
	curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
	if($header){
		curl_setopt($ch, CURLOPT_HEADER, TRUE);
	}
	if($cookie){
		curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	}
	if($referer){
		if($referer==1){
			curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
		}else{
			curl_setopt($ch, CURLOPT_REFERER, $referer);
		}
	}
	if($ua){
		curl_setopt($ch, CURLOPT_USERAGENT,$ua);
	}else{
		curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36');
	}
	if($nobaody){
		curl_setopt($ch, CURLOPT_NOBODY,1);
	}
	curl_setopt($ch, CURLOPT_ENCODING, "gzip");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);   
	curl_setopt( $ch, CURLOPT_FOLLOWLOCATION,true);
	$ret = curl_exec($ch);
	curl_close($ch);
	return $ret;
}
?>