<?php
error_reporting(0);//屏蔽错误,防止暴路径
header('Content-type:text/json');//输出内格式为JSON
date_default_timezone_set('Asia/Shanghai');
include_once("../../includes/autoloader.php");
Autoloader::register();
require '../../config.php';
//连接数据库
$DB = new \lib\PdoHelper($dbconfig);
$CACHE=new \lib\Cache();
$conf=$CACHE->pre_fetch();
if(empty($conf['cronkey']))exit("请先设置好监控密钥");
if($conf['cronkey']!=$_GET['cronkey'])exit("监控密钥不正确");
$key = $conf['admin_user'].$conf['cronkey'];
include('./sdk/class.rc4crypt.php');//引入SDK文件,方便快捷！
$rc4 = new Crypt_RC4();//初始化SDK
$rc4 -> setKey($key);//设置RC4密匙
$data = $rc4->decrypt(base64_decode(file_get_contents('php://input')));
$json = json_decode($data,true);
if($conf['admin_user']!=$json['user'])exit('{"code":-1,"msg":"账号不正确"}');
if($conf['cronkey']!=$json['cronkey'])exit('{"code":-1,"msg":"监控密钥不正确"}');
switch($json['type']){
case 'row':
	$row = $DB->getRow($json['sql']);
	exit(json_encode($row));
break;
case 'getAll':
	$arr = $DB->getAll($json['sql']);
	exit(json_encode($arr));
break;
case 'exec':
	$ret_arr = array();
	$sql = explode(';',$json['sql']);
	foreach ($sql as $value) {
		$ret = $DB->exec($value);
		$ret_arr[] = array('code' => $ret,'error' => $DB->error());
	}
	exit(json_encode($ret_arr));
break;
case 'getColumn':
	$count = $DB->getColumn($json['sql']);
	exit($count);
break;
default:
	exit('{"code":-1,"msg":"No Act"}');
break;
}
?>