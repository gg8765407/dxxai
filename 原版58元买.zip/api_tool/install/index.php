<?php
$nosession = true;
include("../../includes/common.php");
@header('Content-Type: text/html; charset=UTF-8');
if(file_exists('install.lock')){
	exit('已经执行过了！');
}
//建立 价钱变动表
$sql ="DROP TABLE IF EXISTS `pre_goods_change`;
CREATE TABLE `pre_goods_change` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `active` varchar(255) DEFAULT NULL COMMENT '1显示0隐藏',
  `close` varchar(255) DEFAULT NULL COMMENT '0上架1下架',
  `alert` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `changetime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;
";
$DB->exec($sql);

//建立 一级分类表
$sql ="DROP TABLE IF EXISTS `pre_class_one`;
CREATE TABLE `pre_class_one` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `active` int(11) DEFAULT '0',
  `shopimg` varchar(255) DEFAULT NULL,
  `blocklogin` tinyint(1) NOT NULL DEFAULT '0',
  `white` text NULL,
  PRIMARY KEY (`cid`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;
";
$DB->exec($sql);

//新增字段
//shua_class
$DB->exec("ALTER TABLE `pre_class` ADD COLUMN `oneid` varchar(255) NULL DEFAULT '0'");

//shua_orders
$DB->exec("ALTER TABLE `pre_orders` ADD COLUMN `xbc_djstate` varchar(255) NULL DEFAULT NULL");
$DB->exec("ALTER TABLE `pre_orders` ADD COLUMN `xbc_start_num` varchar(255) NULL DEFAULT NULL");
$DB->exec("ALTER TABLE `pre_orders` ADD COLUMN `xbc_now_num` varchar(255) NULL DEFAULT NULL");
$DB->exec("ALTER TABLE `pre_orders` ADD COLUMN `xbc_end_num` varchar(255) NULL DEFAULT NULL");
$DB->exec("ALTER TABLE `pre_orders` ADD COLUMN `xbc_orders_time` varchar(255) NULL DEFAULT NULL");
$DB->exec("ALTER TABLE `shua_orders` ADD COLUMN `xbc_uptime` int(11) NOT NULL DEFAULT 0");

//shua_pay
$DB->exec("ALTER TABLE `pre_pay` ADD COLUMN `shequid` int(11) DEFAULT NULL");



@file_put_contents("install.lock",'安装锁');
exit('执行成功！');


?>