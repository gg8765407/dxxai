<?php
$is_jiuwu_url = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
if(stripos($is_jiuwu_url.'】','m=home&c=order&a=add')){		//m=home&c=order&a=add   下单接口
	//单参数 zh=[value1]&need_num_0=[num]&goods_id=799&goods_type=1320
	//多参数 zh=[value1]|[value2]|[value3]&mm=[value2]&need_num_0=[num]&goods_id=506&goods_type=966
	
	include("./includes/common.php");
	@header('Content-Type: application/json; charset=UTF-8');
	$user = trim(daddslashes($_POST['Api_UserName']));
	$pass = trim(daddslashes($_POST['Api_UserMd5Pass']));	//md5加密后的值
	$tid = intval($_POST['goods_id']);
	$cid = intval($_POST['goods_type']);
	$num = isset($_POST['need_num_0']) ? intval($_POST['need_num_0']) : 1;
	$input = htmlspecialchars(trim(strip_tags(daddslashes($_POST['zh']))));
	$row = $DB->getRow("SELECT * FROM `pre_site` WHERE `user` = '{$user}' LIMIT 1");

	if($pass != md5($row['pwd'])){
		exit('{"status":0,"info":"密码不正确！"}');
	}
	
	if($cid == '544'){//检测拉圈圈订单  544 是商品id
		$input2 = explode("|",$input);
		$data_lqq = dsw_lqqcx($siteurl, $user, $row['pwd'],$input2[0]);
		$data_lqq_json = json_decode($data_lqq,true);
		if($data_lqq_json['code']!='1'){	//自动类型  处理失败 退款处理
			exit('{"status":0,"info":"没有圈圈信息、或软件掉线、或DIY名片过于花里胡俏、选择手工类型下单"}');
		}

	}
	$ret = do_dsw_api($siteurl,$user,$row['pwd'],$tid,$num,$input);
	if($ret['code'] == '0'){//下单成功
		exit('{"status":1,"info":"下单成功！","order_id":"'.$ret['id'].'"}');
	}else{
		exit('{"status":0,"'.$ret['message'].'"}');
	}

exit;
}elseif(stripos($is_jiuwu_url.'】','m=Home&c=Order&a=query_orders_detail')){	// 查询订单进度

	include("./includes/common.php");
	@header('Content-Type: application/json; charset=UTF-8');
	$user = trim(daddslashes($_POST['Api_UserName']));
	$pass = trim(daddslashes($_POST['Api_UserMd5Pass']));	//md5加密后的值
	$ids = trim(daddslashes($_POST['orders_id']));
	$row = $DB->getRow("SELECT * FROM `pre_site` WHERE `user` = '{$user}' LIMIT 1");
	if($pass != md5($row['pwd'])){
		exit('{"status":0,"info":"密码不正确！"}');
	}
	$id = "'".implode("','",explode(",",$ids))."'";
	$rs=$DB->query("SELECT A.* ,B.tid as stid ,B.value as svalue FROM pre_orders A LEFT JOIN pre_tools B ON A.tid=B.tid WHERE A.id in({$id}) order by id asc LIMIT 1000");
	//$rs=$DB->query("SELECT * FROM pre_orders WHERE id in({$id}) order by id asc");
	$order_state = array("未开始", "未开始", "进行中", "已完成", "已退单", "退单中", "续费中", "补单中", "改密中", "登录失败");//玖伍的
	$ds_order_state = array("0" => "1" ,"1" => "3" ,"2" => "2" ,"3" => "8" ,"4" => "4"); //0 待处理 1 已完成 2正在处理 3异常 4已退款
	$rows = array();
	$i=0;
	while($res = $rs->fetch()){
		$num = $res['value'] * $res['svalue'];
		$rows[] = array(
			"id" => $res['id'],
			"need_num_0" => $num,
			"start_num" => $res['xbc_start_num'],
			"end_num" => $res['xbc_end_num'],
			"now_num" => $res['xbc_now_num'],
			"order_state" => $ds_order_state[$res['status']],
			"login_state" => $res['id'],
			"start_time" => $res['addtime'],
			"end_time" => $res['endtime'],
			"add_time" => $res['addtime']
		);
		$i++;
	}
	if($i == 0){
		$status = false;
	}else{
		$status = true;
	}
	$result=array("total"=>$i,"rows"=>$rows,"status"=>true);
	exit(json_encode($result));
}elseif(stripos($is_jiuwu_url.'】','m=home&c=api&a=get_goods_lists')){	//获取商品
	$rs=$DB->query("SELECT * FROM pre_tools WHERE active='1' AND close='0' order by id asc");//代刷网 active -1为显示  0为隐藏  close 0为上架  1为下架
	$rows = array();
	$i=0;
	while($res = $rs->fetch()){
		$rows[] = array(
			"id" => $res['tid'],
			"title" => $res['name'],
			"thumb" => $res['shopimg'],
			"streamline_title" => $res['name'],
			"goods_type" => $res['tid'],
			"goods_type_title" => $res['name'],
			"unit" => '个',
			"minbuynum_0" => $res['min'],
			"maxbuynum_0" => $res['max']
		);
		$i++;
	}
	$result=array("status"=>1,"goods_rows"=>$rows);
	exit(json_encode($result));
}elseif(stripos($is_jiuwu_url.'】','m=home&c=api&a=user_get_goods_lists_details')){	//获取商品-账号密码
	include("./includes/common.php");
	@header('Content-Type: application/json; charset=UTF-8');
	$user = trim(daddslashes($_GET['Api_UserName']));
	$pass = trim(daddslashes($_GET['Api_UserMd5Pass']));	//md5加密后的值
	$userrow = $DB->getRow("SELECT * FROM `pre_site` WHERE `user` = '{$user}' LIMIT 1");
	if($pass == md5($userrow['pwd'])){
		//$price_obj = new \lib\Price($userrow['zid'],$userrow);
		
	}else{
		exit('{"status":0,"info":"密码不正确！"}');
	}
	$islogin2 = 1;
	
	//exit("__DIR__:  ========>  ".__DIR__);
	//exit(json_encode($userrow));
	//$price_obj = new \includes\lib\Price($userrow['zid'],$userrow);
	
/* 	if(isset($price_obj)){
		exit('1');
	}else{
		exit('2');
	} */
	
	
	$rs=$DB->query("SELECT * FROM pre_tools WHERE active='1' AND close='0' order by id asc");//代刷网 active -1为显示  0为隐藏  close 0为上架  1为下架
	$rows = array();
	while($res = $rs->fetch()){
/* 		if($islogin2 == 1 && isset($price_obj)){
			$price_obj->setToolInfo($res['tid'],$res);
			$price = $price_obj->getToolPrice($res['tid']);
		}else{
			$price = $res['price'];
		} */
		$rows[] = array(
			"id" => $res['tid'],
			"title" => $res['name'],
			"thumb" => $res['shopimg'],
			"unit" => '个',
			"goods_unitprice" => $res['price'] * 1.05,
			"user_unitprice" => $res['price'] * 1.05,
			"no_display" => 0,
			"goods_status" => 0,
			"goods_close_msg" => '正常下单',
			"minbuynum_0" => $res['min'],
			"maxbuynum_0" => $res['max'],
			"goods_type" => $res['tid'],
			"goods_type_title" => $res['name']
		);
	}
	$result=array("status"=>true,"msg"=>"获取成功","user_goods_lists_details"=>$rows);
	exit(json_encode($result));
}

//拉圈圈查询
function dsw_lqqcx($url,$user,$pwd,$qq){
	$url = $url.'api_tool/lqq/api.php?jk=cx&qq='.$qq;
	$post = 'user='.$user.'&pass='.$pwd;
	$data = get_curl($url,$post);
	return $data;
}
//提交订单
function do_dsw_api($url,$user,$pwd,$tid,$num=1,$input){
	$param = array();
	$url = $url.'api.php?act=pay';
	$result['code'] = -1;
	$param['tid'] = $tid;
	$param['user'] = $user;
	$param['pass'] = $pwd;
	$param['num'] = $num;
	$input = explode("|",$input);
	if(is_array($input) && $input) {
		$i = 1; 
		foreach ($input as $val) {
			if($val){
				$param[ 'input' . $i ] = $val;
				$i++;
			}
		}
	}
	$post = http_build_query($param);
	$data = get_curl($url,$post);
	$json = json_decode($data,true);
	if (isset($json['orderid'])) {
		$result = array(
			'code' => 0,
			'id' => $json['orderid']
		);
		if($json['faka']==true){
			$result['faka']=true;
			$result['kmdata']=$json['kmdata'];
		}
	} elseif(isset($json['message'])){
		$result['message'] = $json['message'];
	} else{
		$result['message'] = $data;
	}
	return $result;	
}
?>