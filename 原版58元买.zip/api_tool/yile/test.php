<?php
// +----------------------------------------------------------------------
// | Author: 小白菜
// +----------------------------------------------------------------------
// | qq: 694319649
// +----------------------------------------------------------------------
// | Date: 2021年6月26日
// +----------------------------------------------------------------------
// | 亿乐对接小白菜社区
// +----------------------------------------------------------------------
$end_memory = memory_get_usage();
require('config.php');
$yile_url = $config['yile_url'];
$yile_id = $config['yile_id'];
$yile_key = $config['yile_key'];
////////////
if(preg_match('/Baiduspider/', $_SERVER['HTTP_USER_AGENT']))exit;
$act=isset($_GET['act'])?$_GET['act']:null;
@header('Content-Type: text/html; charset=UTF-8');
if (function_exists("set_time_limit")){@set_time_limit(0);}

/* //echo yile_order($yile_url,$yile_id,$yile_key);

	$aa=json_decode(yile_order($yile_url,$yile_id,$yile_key,'1','10'),true);
	foreach($aa['data'] as $row){
		echo $row['id'].'<br>';
		echo json_encode($row['id']).'<br>';
		//$date[]=	
	}
exit;	 */
//sleep
$date=array();
for($i=1; $i<=2; $i++){
	$aa=json_decode(yile_order($yile_url,$yile_id,$yile_key,$i),true);
	
	//echo $aa;
	
 	foreach($aa['data'] as $row){
		//echo $row['id'].'<br>';
		$date[]=$row['id'];
	}
	
	//echo '<br><br>延迟1秒<hr><br><br>';
	sleep(1);
}





echo json_encode($date);
echo '<br><br>延迟1秒<hr><br><br>';
echo implode(',',$date);

echo yile_info($yile_url,$yile_id,$yile_key,implode(',',$date));


$start_memory = memory_get_usage();
echo '<br><br>整个过程耗内存：'.round(($end_memory-$start_memory)/(1024*1024),3).'M<br>';
echo 'end_memory整个过程耗内存：'.round($end_memory/(1024*1024),3).'M<br><br>';
echo 'start_memory整个过程耗内存：'.round($start_memory/(1024*1024),3).'M<br>';
exit;
 
$date = date("Y-m-d H:i:s");
$id=isset($_POST['id'])?$_POST['id']:null;
$gid=isset($_POST['gid'])?$_POST['gid']:null;
$model_id=isset($_POST['model_id'])?$_POST['model_id']:null;
$num=isset($_POST['num'])?$_POST['num']:1;
$start_num=isset($_POST['start_num'])?$_POST['start_num']:null;
$now_num=isset($_POST['now_num'])?$_POST['now_num']:null;
$status=isset($_POST['status'])?$_POST['status']:null;
$value1=isset($_POST['value1'])?$_POST['value1']:null;
$value2=isset($_POST['value2'])?$_POST['value2']:null;
$value3=isset($_POST['value3'])?$_POST['value3']:null;
$value4=isset($_POST['value4'])?$_POST['value4']:null;
$value5=isset($_POST['value5'])?$_POST['value5']:null;
$value6=isset($_POST['value6'])?$_POST['value6']:null;
$money=isset($_POST['money'])?$_POST['money']:null;
$tid=intval($_GET['tid']);
if(!$tid)exit('{"code":-1,"msg":"商品ID不能为空"}');
if(!$id)exit('{"code":-1,"msg":"订单ID不能为空"}');
switch($act){	
case 'do':
	$result='';
	if(isset($_GET['zd'])){//检测拉圈圈订单
		$data_lqq = dsw_lqqcx($config['url'],$config['user'],$config['pwd'],$value1);
		$data_lqq_json = json_decode($data_lqq,true);
		if($data_lqq_json['code']=='-1'){	//自动类型  处理失败 退款处理
			$asdsd = yile_refund($yile_url,$yile_id,$yile_key,$id,'92','2',$money,$data_lqq_json['msg']);//退款
			exit;
		}else{
			$result=$data_lqq;
		}
	}
	$input = $value1.($value2?'|'.$value2:null).($value3?'|'.$value3:null).($value4?'|'.$value4:null).($value5?'|'.$value5:null).($value6?'|'.$value6:null);
	$data = dsw_do($config['url'],$config['user'],$config['pwd'],$tid,$num,$input);	
	if($data['code'] == '0'){//下单成功
		if($data['faka'] == true){
			foreach($data['kmdata'] as $row){
				$result.=$row['card'].'----';
			}
			$result = '卡密：'.substr($result,0,strlen($result)-4);
		}else{
			$result .= '订单id:'.$data['id'];
		}
		$asdsd = yile_status($yile_url,$yile_id,$yile_key,$id,'90',$result);
	}else{//下单失败退款
		$asdsd = yile_refund($yile_url,$yile_id,$yile_key,$id,'92','2',$money,$data['message']);
	}
	exit;
	break;
default:
	exit('{"code":-4,"msg":"No Act"}');
	break;
}

//提交订单
function dsw_do($url,$user,$pwd,$tid,$num=1,$input){
	$param = array();
	$url = $url.'/api.php?act=pay';
	$result['code'] = -1;
	$param['tid'] = $tid;
	$param['user'] = $user;
	$param['pass'] = $pwd;
	$param['num'] = $num;
	$input = explode("|",$input);
	if(is_array($input) && $input) {
		$i = 1; 
		foreach ($input as $val) {
			if($val){
				$param[ 'input' . $i ] = $val;
				$i++;
			}
		}
	}
	$post = http_build_query($param);
	$data = get_curl($url,$post);
	$json = json_decode($data,true);
	if (isset($json['orderid'])) {
		$result = array(
			'code' => 0,
			'id' => $json['orderid']
		);
		if($json['faka']==true){
			$result['faka']=true;
			$result['kmdata']=$json['kmdata'];
		}
	} elseif(isset($json['message'])){
		$result['message'] = $json['message'];
	} else{
		$result['message'] = $data;
	}
	return $result;	
}
//获取单个商品信息
function dsw_tools($url,$user,$pwd,$tid){
	$url = $url.'/api_tool/api/api.php?act=tools&tid='.$tid;
	$data = get_curl($url);
	return $data;
}
function dsw_lqqcx($url,$user,$pwd,$qq){
	$url = $url.'/api_tool/api/api.php?act=lqqcx&qq='.$qq;
	$post = 'user='.$user.'&pass='.$pwd;
	$data = get_curl($url,$post);
	return $data;
}
//亿乐获取订单列表
function yile_order($url,$api_token,$key,$page=1,$pageSize=200,$gid="",$status=1,$id="",$join_status=1,$orderBy=""){
	$url = $url.'.api.94sq.cn/api/order/list';
	$post = array(
		"api_token" =>$api_token,
		"timestamp" => time(),
		"page" => $page,
		"pageSize" => $pageSize,
		"gid" => $gid,
		"status" => $status,
		"id" => $id,
		"join_status" => $join_status,
		"orderBy" => $orderBy
	);
	$sign = getSign($post,$key);
	$post["sign"] = $sign;
	$post2 = http_build_query($post);
	$data = get_curl($url,$post2);
	return $data;
}
//亿乐获取订单详情
function yile_info($url,$api_token,$key,$id){
	$url = $url.'.api.94sq.cn/api/order/info';
	$post = array(
		"api_token" =>$api_token,
		"timestamp" => time(),
		"ids" => $id
	);
	$sign = getSign($post,$key);
	$post["sign"] = $sign;
	$post2 = http_build_query($post);
	$data = get_curl($url,$post2);
	return $data;
}
//亿乐更改订单状态
function yile_status($url,$api_token,$key,$ids,$status,$remark=0){
	$url = $url.'.api.94sq.cn/api/order/status';
	$post = array("api_token" =>$api_token, "timestamp" => time(), "ids" => $ids, "status" => $status, "remark" => $remark);
	$sign = getSign($post,$key);
	$post["sign"] = $sign;
	$post2 = http_build_query($post);
	$data = get_curl($url,$post2);
	return $data;
}
//亿乐退款
function yile_refund($url,$api_token,$key,$id,$status,$type,$num,$remark=0){
	$url = $url.'.api.94sq.cn/api/order/refund';
	if($remark){
		$post = array("api_token" =>$api_token, "timestamp" => time(), "id" => $id, "status" => $status, "type" => $type, "num" => $num, "remark" => $remark);
	}else{
		$post = array("api_token" =>$api_token, "timestamp" => time(), "id" => $id, "status" => $status, "type" => $type, "num" => $num);
	}
	$sign = getSign($post,$key);
	$post["sign"] = $sign;
	$post2 = http_build_query($post);
	$data = get_curl($url,$post2);
	
	if (!($data = json_decode($data, true))) {
		return "打开对接网站失败";
	}
	
	if ($data["status"] !== 0) {
		return $data["message"];
	}else{
		return $data["message"];
	}
}
//亿乐签名
function getSign($param,$key){
	$signPars = "";
	ksort($param);
	foreach ($param as $k => $v) {
		if ("sign" != $k && "" != $v) {
			$signPars .= $k . "=" . $v . "&";
		}
	}
	$signPars = trim($signPars, '&');
	$signPars .= $key;
	$sign = md5($signPars);
	return $sign;
}
//CURL
function get_curl($url,$post=0,$referer=0,$cookie=0,$header=0,$ua=0,$nobaody=0){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);       
	$httpheader[] = "Accept: */*";
	$httpheader[] = "Accept-Encoding: gzip,deflate,sdch";
	$httpheader[] = "Accept-Language: zh-CN,zh;q=0.8";
	$httpheader[] = "Connection: close";
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	if($post){
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		$httpheader[] = "Content-Type: application/x-www-form-urlencoded; charset=UTF-8";
	}
	curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
	if($header){
		curl_setopt($ch, CURLOPT_HEADER, TRUE);
	}
	if($cookie){
		curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	}
	if($referer){
		if($referer==1){
			curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
		}else{
			curl_setopt($ch, CURLOPT_REFERER, $referer);
		}
	}
	if($ua){
		curl_setopt($ch, CURLOPT_USERAGENT,$ua);
	}else{
		curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36');
	}
	if($nobaody){
		curl_setopt($ch, CURLOPT_NOBODY,1);
	}
	curl_setopt($ch, CURLOPT_ENCODING, "gzip");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);   
	curl_setopt( $ch, CURLOPT_FOLLOWLOCATION,true);
	$ret = curl_exec($ch);
	curl_close($ch);
	return $ret;
}
exit;
?>