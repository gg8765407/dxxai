<?php
// +----------------------------------------------------------------------
// | Author: 小白菜
// +----------------------------------------------------------------------
// | qq: 694319649
// +----------------------------------------------------------------------
// | Date: 2021年6月26日
// +----------------------------------------------------------------------
// | 亿乐对接小白菜社区
// +----------------------------------------------------------------------
require('config.php');
$yile_url = $config['yile_url'];
$yile_id = $config['yile_id'];
$yile_key = $config['yile_key'];
////////////
/*
	
 */
 //秒赞api网址  结尾不带 斜杠 /
	$zan_url = 'http://mz.0mz.cn';
 
 //秒赞账号
	$zan_user = 'aaaaa';
 
 //秒赞密码
	$zan_pwd = '123456';
 
 
////////////
if(preg_match('/Baiduspider/', $_SERVER['HTTP_USER_AGENT']))exit;
$act=isset($_GET['act'])?$_GET['act']:null;
@header('Content-Type: text/html; charset=UTF-8');
if (function_exists("set_time_limit")){@set_time_limit(0);}
 
$id=isset($_POST['id'])?$_POST['id']:null;
$gid=isset($_POST['gid'])?$_POST['gid']:null;
$model_id=isset($_POST['model_id'])?$_POST['model_id']:null;
$num=isset($_POST['num'])?$_POST['num']:1;
$start_num=isset($_POST['start_num'])?$_POST['start_num']:null;
$now_num=isset($_POST['now_num'])?$_POST['now_num']:null;
$status=isset($_POST['status'])?$_POST['status']:null;
$value1=isset($_POST['value1'])?$_POST['value1']:null;
$value2=isset($_POST['value2'])?$_POST['value2']:null;
$value3=isset($_POST['value3'])?$_POST['value3']:null;
$value4=isset($_POST['value4'])?$_POST['value4']:null;
$value5=isset($_POST['value5'])?$_POST['value5']:null;
$value6=isset($_POST['value6'])?$_POST['value6']:null;
$money=isset($_POST['money'])?$_POST['money']:null;
if(!$id)exit('{"code":-1,"msg":"订单ID不能为空"}');
switch($act){	
case 'do':
	$url = $zan_url.'/api/api.php?act=do';
	$post = 'qq='.$value1.'&sum='.$num.'&user='.$zan_user.'&pwd='.$zan_pwd;
	$json = get_curl($url,$post);
	$data = json_decode($json,true);	
	if($data['code'] == '1'){

		$ret = yile_status($yile_url,$yile_id,$yile_key,$id,'90',$data['msg']);
		file_put_contents('yile_ok.txt','下单成功----'.$ret);//写出文件	
		
	}else{
		$ret = yile_refund($yile_url,$yile_id,$yile_key,$id,'92','2',$money,$data['msg']);//退款
		file_put_contents('yile_no.txt','下单失败----'.$ret);//写出文件
	}
	
	exit;
	break;
default:
	exit('{"code":-4,"msg":"No Act"}');
	break;
}

//亿乐更改订单状态
function yile_status($url,$api_token,$key,$ids,$status,$remark=0){
	$url = $url.'.api.yilesup.net/api/order/status';
	$post = array("api_token" =>$api_token, "timestamp" => time(), "ids" => $ids, "status" => $status, "remark" => $remark);
	$sign = getSign($post,$key);
	$post["sign"] = $sign;
	$post2 = http_build_query($post);
	$data = get_curl($url,$post2);
	return $data;
}
//亿乐退款
function yile_refund($url,$api_token,$key,$id,$status,$type,$num,$remark=0){
	$url = $url.'.api.yilesup.net/api/order/refund';
	if($remark){
		$post = array("api_token" =>$api_token, "timestamp" => time(), "id" => $id, "status" => $status, "type" => $type, "num" => $num, "remark" => $remark);
	}else{
		$post = array("api_token" =>$api_token, "timestamp" => time(), "id" => $id, "status" => $status, "type" => $type, "num" => $num);
	}
	$sign = getSign($post,$key);
	$post["sign"] = $sign;
	$post2 = http_build_query($post);
	$data = get_curl($url,$post2);
	
	if (!($data = json_decode($data, true))) {
		return "打开对接网站失败";
	}
	
	if ($data["status"] !== 0) {
		return $data["message"];
	}else{
		return $data["message"];
	}
}
//亿乐签名
function getSign($param,$key){
	$signPars = "";
	ksort($param);
	foreach ($param as $k => $v) {
		if ("sign" != $k && "" != $v) {
			$signPars .= $k . "=" . $v . "&";
		}
	}
	$signPars = trim($signPars, '&');
	$signPars .= $key;
	$sign = md5($signPars);
	return $sign;
}
//CURL
function get_curl($url,$post=0,$referer=0,$cookie=0,$header=0,$ua=0,$nobaody=0){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);       
	$httpheader[] = "Accept: */*";
	$httpheader[] = "Accept-Encoding: gzip,deflate,sdch";
	$httpheader[] = "Accept-Language: zh-CN,zh;q=0.8";
	$httpheader[] = "Connection: close";
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	if($post){
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		$httpheader[] = "Content-Type: application/x-www-form-urlencoded; charset=UTF-8";
	}
	curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
	if($header){
		curl_setopt($ch, CURLOPT_HEADER, TRUE);
	}
	if($cookie){
		curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	}
	if($referer){
		if($referer==1){
			curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
		}else{
			curl_setopt($ch, CURLOPT_REFERER, $referer);
		}
	}
	if($ua){
		curl_setopt($ch, CURLOPT_USERAGENT,$ua);
	}else{
		curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36');
	}
	if($nobaody){
		curl_setopt($ch, CURLOPT_NOBODY,1);
	}
	curl_setopt($ch, CURLOPT_ENCODING, "gzip");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);   
	curl_setopt( $ch, CURLOPT_FOLLOWLOCATION,true);
	$ret = curl_exec($ch);
	curl_close($ch);
	return $ret;
}
exit;
?>