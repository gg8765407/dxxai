<?php
/*数据库配置 本地数据库*/
//网址必须有协议头， 且不能以 / 结尾
//正确的填法如：http://qqzan.cc
$config=array(
	//填写自己的亿乐社区信息
	'yile_url' => 'http://xxxxx.com', //亿乐网址
	'yile_id' => '153940', //亿乐编号
	'yile_key' => '2debf31b8s4a955d7ef14ba1b1137e', //亿乐密钥
	
	'url' => 'https://qqzan.cc', //代刷网网址
	'user' => 'test', //代刷网账号
	'pwd' => 'qiao1997', //代刷网密码
);


?>