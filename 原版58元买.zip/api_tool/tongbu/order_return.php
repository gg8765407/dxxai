 <?php
@header('Content-Type: text/html; charset=UTF-8');
@set_time_limit(0);
include("../../includes/common.php");
if(empty($conf['cronkey']))exit("请先设置好监控密钥");
if($conf['cronkey']!=$_GET['key'])exit("监控密钥不正确");
$stime=microtime(true);

$arr = shangzhan_chadan_row('http://open.shangzhanwl.com','10585','c6f64bc19f64fecbb66779982c89f745','API2205261908471058524359');

print_r($arr);

exit;


$shequid =array();
$data =array();
$list = $DB->query("
SELECT  a.*,b.shequid,c.type FROM
((shua_orders a LEFT JOIN shua_pay b ON a.tradeno = b.trade_no) LEFT JOIN shua_shequ c ON b.shequid = c.id) 
where b.shequid<>0 and c.type in('jiuwu','yile','daishua','shangzhanwl') and a.status in(2,3) ORDER BY a.addtime DESC LIMIT 1000
")->fetchAll(2);

foreach($list as $list_row){//获取所有社区信息
	$shequid[]=$list_row['shequid'];//分类ID
	$data[] = array('id'=>$list_row['id'],'jid'=>$list_row['djorder'],'status'=>$list_row['status'],'shequid'=>$list_row['shequid'],'xbc_djstate'=>$list_row['xbc_djstate'],'addtime'=>$list_row['addtime']);
}
$shequid = array_values(array_unique($shequid));//取出重复数组
$id =array();
$jid =array();
$addtime =array();
$merge=array();
$order=array();
$i=0;
foreach($shequid as $sq_id){//遍历对接的社区
	//先获取社区的信息
	$sq = $DB->getRow("SELECT * FROM `pre_shequ`  WHERE id='{$sq_id}'");
	foreach($data as $data_row){//遍历 $data数据 取出跟社区id相同的订单信息
		if($data_row['shequid'] == $sq_id){
			$id[]=$data_row['id'];
			$jid[]=$data_row['jid'];
			$addtime[]=$data_row['addtime'];
			$merge[$data_row['id']] = $data_row['jid'];//对接订单id如：{"自己订单id":"对接订单id"}
		}
	}
	if($sq['protocol'] == '1'){// https
		$url = 'https://'.$sq['url'];
	}else{
		$url = 'http://'.$sq['url'];
	}
	$order[] = array("type"=>$sq['type'] ,"shequid"=>$sq_id ,"url"=>$url ,"user"=>$sq['username'] ,"pwd"=>$sq['password'],"paypwd"=>$sq['paypwd'] ,"data"=>array("id"=>$id,"jid"=>$jid,"addtime"=>$addtime,"merge"=>$merge));
	$id =array();
	$jid =array();
	$addtime =array();
	$merge =array();
	$i++;
}

if(empty($order)){
	exit('没有订单可操作！');
}else{

	$etime=microtime(true);//获取程序执行结束的时间
	$total=$etime-$stime;  //计算差值
	echo '订单拆分、合并，共耗时='.$total.'<br><br>';
}

$xbc_djstate = array();
$xbc_start_num = array();
$xbc_now_num = array();
$xbc_end_num = array();
$dsw_djorder = array();
$dsw_logs_id = array();
$dsw_status = array();
$dsw_id = array();
$dsw_orders_time = array();
$dsw_endtime = array();
$i = 0;

foreach($order as $row){//遍历 合并好的 $order 数据
	
	if($row['type'] == 'jiuwu'){
		//社区域名、账号、密码、订单号
		$jiuwu_data = jiuwu_chadan_xbc($row['url'],$row['user'],$row['pwd'],implode(',',$row['data']['jid']));
		$jiuwu_data_json = json_decode($jiuwu_data, true);
		foreach($jiuwu_data_json as $jiuwu_data_row){

			$ds_id = array_search($jiuwu_data_row['id'], $row['data']['merge']); //通过值来获取键
			$order_state = array("未开始", "未开始", "进行中", "已完成", "已退单", "退单中", "续费中", "补单中", "改密中", "登录失败");
			if($jiuwu_data_row["order_state"] == '3'){//已完成
				$dsw_status[] = "WHEN ".$ds_id." THEN '1'";	//代刷网订单状态
			}else{
				$dsw_status[] = "WHEN ".$ds_id." THEN '2'";	//代刷网订单状态
			}

			$strtime = Sec1Time($jiuwu_data_row["add_time"],$date); //订单完成的时间
			$dsw_endtime[] = "WHEN '".$ds_id."' THEN '".$date."'";
			$dsw_orders_time[] = "WHEN '".$ds_id."' THEN '".$strtime['time']."'";

			$xbc_djstate[]= "WHEN ".$ds_id." THEN '".$order_state[$jiuwu_data_row['order_state']]."'";	//社区 的 订单状态
			$xbc_start_num[] = "WHEN ".$ds_id." THEN '".$jiuwu_data_row['start_num']."'";	//初始值
			$xbc_now_num[] = "WHEN ".$ds_id." THEN '".$jiuwu_data_row['now_num']."'";		//当前值
			$xbc_end_num[] = "WHEN ".$ds_id." THEN '".($jiuwu_data_row['now_num']-$jiuwu_data_row['start_num'])."'";		//已执行的数量
			$dsw_id[]=$ds_id;	//代刷网的订单号
			$i++;
		}

		
	}elseif($row['type'] == 'yile'){



		$yile_status = array(0 => "等待中", 1 => "进行中", 2 => "退单中", 3 => "已退单", 4 => "异常中", 5 => "补单中", 6 => "已更新", 90 => "已完成", 92 => "已退款");
		//社区域名、订单号、账号、密码
		$yile_data = yile_chadan_xbc($row['url'],implode(',',$row['data']['jid']),$row['user'],$row['pwd']);
	
		foreach($yile_data as $yile_data_row){

			$ds_id = array_search($yile_data_row['id'], $row['data']['merge']); //通过值来获取键
			if($yile_data_row["status"] == '90'){//已完成
				$dsw_status[] = "WHEN ".$ds_id." THEN '1'";	//代刷网订单状态 为 完成
			}elseif($yile_data_row["status"] == '3' || $yile_data_row["status"] == '92'){
				$dsw_status[] = "WHEN ".$ds_id." THEN '3'";	//代刷网订单状态 为 异常
			}else{
				$dsw_status[] = "WHEN ".$ds_id." THEN '2'";	//代刷网订单状态 为 正在处理
			}

			$strtime = Sec1Time($yile_data_row["created_at"],$date); //订单完成的时间
			$dsw_endtime[] = "WHEN '".$ds_id."' THEN '".$date."'";
			$dsw_orders_time[] = "WHEN '".$ds_id."' THEN '".$strtime['time']."'";
			$xbc_djstate[]= "WHEN ".$ds_id." THEN '".$yile_status[$yile_data_row['status']]."'";	//社区 的 订单状态
			$xbc_start_num[] = "WHEN ".$ds_id." THEN '".$yile_data_row['start_num']."'";	//初始值
			$xbc_now_num[] = "WHEN ".$ds_id." THEN '".$yile_data_row['now_num']."'";		//当前值
			$xbc_end_num[] = "WHEN ".$ds_id." THEN '".($yile_data_row['now_num']-$yile_data_row['start_num'])."'";		//已执行的数量
			$dsw_id[]=$ds_id;	//代刷网的订单号
			$i++;
		}
		
	}elseif($row['type'] == 'daishua'){

		//dsw_chadan参数 三 如：1,2,3
		//dsw_chadan参数 四 $status 留空着查询全部状态，查询指定状态如：1,2,3,4
		//id,tid,input,status,xbc_start_num,xbc_now_num,endtime
		$state = array("待处理", "已完成", "正在处理", "异常", "已退单");
		$dsw_data = dsw_chadan($row['url'],$row['user'],$row['pwd'],implode(',',$row['data']['jid']),'');

		foreach(json_decode($dsw_data,true) as $dsw_data_row){
			$ds_id = array_search($dsw_data_row['id'], $row['data']['merge']); //通过值来获取键
			$dsw_status[] = "WHEN ".$ds_id." THEN '".$dsw_data_row["status"]."'";	//代刷网订单状态
			$strtime = Sec1Time($dsw_data_row["endtime"],$date); //订单完成的时间
			$dsw_endtime[] = "WHEN '".$ds_id."' THEN '".$date."'";
			$dsw_orders_time[] = "WHEN '".$ds_id."' THEN '".$strtime['time']."'";
			$xbc_djstate[]= "WHEN ".$ds_id." THEN '".$state[$dsw_data_row['status']]."'";	//社区 的 订单状态
			$xbc_start_num[] = "WHEN ".$ds_id." THEN '".$dsw_data_row['xbc_start_num']."'";	//初始值
			$xbc_now_num[] = "WHEN ".$ds_id." THEN '".$dsw_data_row['xbc_now_num']."'";		//当前值
			$xbc_end_num[] = "WHEN ".$ds_id." THEN '".($dsw_data_row['xbc_now_num']-$dsw_data_row['xbc_start_num'])."'";		//已执行的数量
			$dsw_id[]=$ds_id;	//代刷网的订单号
			$i++;
		}	

	}

	
}


if(!empty($dsw_id)){
	$sql = "
	UPDATE shua_orders 
		SET xbc_djstate = CASE id 
			".implode(' ',$xbc_djstate)."
		END, 
		xbc_start_num = CASE id 
			".implode(' ',$xbc_start_num)."
		END, 
		xbc_now_num = CASE id 
			".implode(' ',$xbc_now_num)."
		END, 
		xbc_end_num = CASE id 
			".implode(' ',$xbc_end_num)."
		END,
		status = CASE id 
			".implode(' ',$dsw_status)."
		END,
		endtime = CASE id 
			".implode(' ',$dsw_endtime)."
		END,
		xbc_orders_time = CASE id 
			".implode(' ',$dsw_orders_time)."
		END
	WHERE id IN (".implode(',',$dsw_id).")
	";

	if($DB->exec($sql)){
		echo '成功<br><br>';
	}else{
		echo '失败'.$DB->error().'<br><br>';
	}
}



$etime=microtime(true);//获取程序执行结束的时间
$total=$etime-$stime;  //计算差值
echo '本次更新订单数量'.$i.'<br><br>';
echo '一共耗时='.$total.'<br><br>';
exit;


//代刷网
function dsw_chadan($url,$user,$pwd,$id,$status){
	$url = $url.'/api_tool/api/api.php?act=search';
	$param = array('user'=>$user, 'pass'=>$pwd, 'id'=>$id, 'status'=>$status);
	$post = http_build_query($param);
	$data = get_curl($url,$post);
	return $data;
	
}
//商战查询订单----单个商品查询
function shangzhan_chadan_row($url,$user,$pwd,$orderno){
	echo $orderno.'<br>';
	$url = $url.'/api.php/Client/orderDetail';
	$order_stats = [0=>'未知', 1=>'待处理', 2=>'正在处理', 3=>'交易成功', 4=>'处理失败', 5=>'成功退款', 6=>'订单异常'];
	$param = array('customerid'=>$user, 'orderno'=>$orderid);
	$sign = md5($user . $pwd);
	$param['sign'] = $sign;
	$post = http_build_query($param);
	$data = get_curl($url,$post);
	return $data;
	
}
//商战查询订单----商战已经废弃这个api接口
function shangzhan_chadan_xbc($url,$user,$pwd,$orderno){
	$url = $url.'/api.php/buyer/getorderInfo';
	$param = array('customerid'=>$user, 'orderno'=>$orderno);
	$sign = md5($user . $orderno . $pwd);
	$param['sign'] = $sign;
	$post = http_build_query($param);
	$data = get_curl($url,$post);
	return $data;
	
}
function jiuwu_chadan_xbc($squrl,$user,$pass,$orders){//社区域名、账号、密码、订单号
	$url = $squrl . "/index.php?m=Home&c=Order&a=query_orders_detail";
	$post = "Api_UserName=" . urlencode($user) . "&Api_UserMd5Pass=" . md5($pass) . "&return_fields=id%2Cneed_num_0%2Cstart_num%2Cend_num%2Cnow_num%2Corder_state%2Clogin_state%2Cstart_time%2Cend_time%2Cadd_time&orders_id=" . $orders;
	$data=get_curl($url, $post);

	if (!($data_json = json_decode($data, true))) {
		return false;
	}
	if ($data_json["status"] == true) {
		return json_encode($data_json["rows"]);
	}
	return $data_json["info"];
}


function yile_chadan_xbc($_arg_0, $_arg_1, $_arg_2, $_arg_3){
	$_var_4 = array(0 => "等待中", 1 => "进行中", 2 => "退单中", 3 => "已退单", 4 => "异常中", 5 => "补单中", 6 => "已更新", 90 => "已完成", 91 => "已退款");
	$_var_5 = $_arg_0 . ".api.94sq.cn/api/order/query";
	$_var_6 = array("api_token" => $_arg_2, "timestamp" => time(), "ids" => $_arg_1);
	$_var_7 = yile_getSign($_var_6, $_arg_3);
	$_var_6["sign"] = $_var_7;
	$_var_8 = http_build_query($_var_6);
	$_var_9 = get_curl($_var_5, $_var_8);
	
	
	if (!($_var_9 = json_decode($_var_9, true))) {
		return false;
	}
	if ($_var_9["status"] !== 0) {
		return $_var_9["message"];
	}
	return $_var_9["data"];
}

//时间计算
function Sec1Time($startdate,$enddate){
	$time= strtotime($enddate) - strtotime($startdate);
	if(is_numeric($time)){
		$str = '';
		$value = array("years" => 0, "days" => 0, "hours" => 0,"minutes" => 0, "seconds" => 0, "time" => 0);
		if($time >= 31556926){
			$value["years"] = floor($time/31556926);
			$str.= $value['years'].'年';
			$time = ($time%31556926);
		}
		if($time >= 86400){
			$value["days"] = floor($time/86400);
			$str.= $value['days'].'天';
			$time = ($time%86400);
		}
		if($time >= 3600){
			$value["hours"] = floor($time/3600);
			$str.= $value['hours'].'时';
			$time = ($time%3600);
		}
		if($time >= 60){
			$value["minutes"] = floor($time/60);
			$str.= $value['minutes'].'分';
			$time = ($time%60);
		}
		$value["seconds"] = floor($time);
		$str.= $value['seconds'].'秒';
		$value["time"] = $str;
		return $value;
	}else{
		return false; 
	}
}
?>

