 <?php
@header('Content-Type: text/html; charset=UTF-8');
@set_time_limit(0);
include("../../includes/common.php");
if(empty($conf['cronkey']))exit("请先设置好监控密钥");
if($conf['cronkey']!=$_GET['key'])exit("监控密钥不正确");
$list = $DB->query("SELECT * FROM pre_orders where xbc_djstate in('已退单','已退款') and status in('2','3')")->fetchAll(2);
foreach($list as $row){
	$zid = intval($row['userid']);
	$start_num = $row['xbc_start_num']; //初始值
	$now_num = $row['xbc_now_num']; //当前值

	//先查下订单是否已经退款，避免重复退款  
	$count=$DB->getColumn("select count(*) from pre_points where bz like '%单(ID{$row['id']})%'");
	if($count>0){
		$DB->exec("update pre_orders set status='4' where id='{$row['id']}'");
		continue;
	}

	//如果 订单数据的 初始值、当前值、都是为0 或相同，就执行【全额退款】如果不想全额退的就屏蔽掉下面的代码----开始
	if($start_num == $now_num){
		
		$DB->exec("update pre_orders set status='4' where id='{$row['id']}'");
		changeUserMoney($zid, $row['money'], true, '退单', '订单(ID'.$row['id'].')已全额退款到余额'.$row['money']);
		rollbackPoint($row['id']);
		echo '订单ID：'.$row['id'].'----已全额退款<br>';
		continue;
		
	}
	//【全额退款】结束
	
	
	//下面是根据剩下没刷的数量进行退款
	$tool=$DB->getRow("select * from pre_tools where tid='{$row['tid']}' limit 1");
	$value=$tool['value']>0?$tool['value']:1;
	$value=$row['value']*$value;//下单数量
	$tnum = $start_num + $value - $now_num;//计算出剩下没刷的数量
	$rmb = $row['money'] / $value;//计算出单个点数的价钱
	$trmb = round($rmb * $tnum,5);//计算出退回的金额	
	$DB->exec("update pre_orders set status='4' where id='{$row['id']}'");
	changeUserMoney($zid, $trmb, true, '退款', '订单(ID'.$row['id'].')订单总额:'.$row['money'].',已退款到余额,退回'.$tnum.'点');
	rollbackPoint($row['id']);
	echo '订单ID：'.$row['id'].'----已退款<br>';
	
}

?>

