 <?php
if(preg_match('/Baiduspider/', $_SERVER['HTTP_USER_AGENT']))exit;
if(function_exists("set_time_limit")){
	@set_time_limit(0);
}
if(function_exists("ignore_user_abort")){
	@ignore_user_abort(true);
}
@header('Content-Type: text/html; charset=UTF-8');
$stime2=microtime(true);
include("../../includes/common.php");
include("./function.php");
if(empty($conf['cronkey']))exit("请先设置好监控密钥");
if($conf['cronkey']!=$_GET['key'])exit("监控密钥不正确");
if(isset($_GET['shequid'])){
	$sql = " id = '".intval($_GET['shequid'])."'";
}else{
	$sql = " type = 'zhike'";
}
$limit=isset($_GET['limit'])?daddslashes($_GET['limit']):3000;
$alert .= '<br><br>同步全部 直客社区<br>'.$siteurl.'cron_zhike.php?key=监控密钥';
$alert .= '<br><br>同指定的社区<br>'.$siteurl.'cron_zhike.php?key=监控密钥&shequid=社区id(对接设置-对接站点管理，里可获取社区ID)';
$alert .= '<br><br>根据自己的情况进行监控，也可以分开多个同时监控';

$n = 0;
$rs=$DB->query("SELECT * FROM `pre_shequ` WHERE{$sql}");
while($sq = $rs->fetch()){
	$url = ($sq['protocol']==1?'https://':'http://') . $sq['url'];
	$rs2=$DB->query("SELECT a.* FROM ((shua_orders a LEFT JOIN shua_pay b ON a.tradeno = b.trade_no) LEFT JOIN shua_shequ c ON b.shequid = c.id) WHERE b.shequid<>0 AND c.id = '{$sq['id']}' AND a.status in(2,3) ORDER BY a.id DESC LIMIT {$limit}");
	$post = array();
	$post_zhike = array();
	$idArr = array();
	$ds_idArr = array();
	$i=0;
	$t = 0;
	while($res = $rs2->fetch()){
		if($res['xbc_djstate'] == '等待退款')continue;
		if($sq['type'] == 'zhike'){
			$stime=microtime(true);
			$state = array(0=>'待处理',1=>'已付款',2=>'处理中',3=>'待确认',4=>'已完成',5=>'退单中',6=>'已退单',7=>'已退款',8=>'待处理');
			$ret = zhike_chadan($url,$sq['username'],$sq['password'],$res['djorder']);
			$ret = json_decode($ret,true);
			if($ret['code'] != 100)continue;
			$v = $ret['result'];

			$i++;
			$xbc_djstate = array();
			$xbc_start_num = array();
			$xbc_now_num = array();
			$xbc_end_num = array();
			$ds_status = array();
			$dsw_id = array();
			$dsw_orders_time = array();
			$dsw_endtime = array();
			$ds_id = $res['id'];
			$djstate = $state[$v['orderState']];
			if($v['orderState'] == '6' || $v['orderState'] == '7'){
				$djstate = '等待退款';
				$t++;
				$ds_status[] = "WHEN ".$ds_id." THEN '3'";
			}elseif($v['orderState'] == '4'){
				$ds_status[] = "WHEN ".$ds_id." THEN '1'";
			}else{
				$ds_status[] = "WHEN ".$ds_id." THEN '2'";
			}
			$strtime = Sec1Time($v['logs'][2]['createdAt'],$date); //订单完成的时间
			$dsw_endtime[] = "WHEN '".$ds_id."' THEN '".$date."'";
			$dsw_orders_time[] = "WHEN '".$ds_id."' THEN '".$strtime['time']."'";
			$xbc_djstate[]= "WHEN ".$ds_id." THEN '".$djstate."'";	//社区 的 订单状态
			$xbc_start_num[] = "WHEN ".$ds_id." THEN '".$v['startNum']."'";	//初始值
			$xbc_now_num[] = "WHEN ".$ds_id." THEN '".$v['currentNum']."'";		//当前值
			$xbc_end_num[] = "WHEN ".$ds_id." THEN '".($v['currentNum']-$v['startNum'])."'";		//已执行的数量
			$dsw_id[]=$ds_id;	//代刷网的订单号
			$sql = "UPDATE shua_orders 
				SET xbc_djstate = CASE id 
					".implode(' ',$xbc_djstate)."
				END, 
				xbc_start_num = CASE id 
					".implode(' ',$xbc_start_num)."
				END, 
				xbc_now_num = CASE id 
					".implode(' ',$xbc_now_num)."
				END, 
				xbc_end_num = CASE id 
					".implode(' ',$xbc_end_num)."
				END,
				status = CASE id 
					".implode(' ',$ds_status)."
				END,
				endtime = CASE id 
					".implode(' ',$dsw_endtime)."
				END,
				xbc_orders_time = CASE id 
					".implode(' ',$dsw_orders_time)."
				END
			WHERE id IN (".implode(',',$dsw_id).")";
			if($DB->exec($sql)){
				echo '订单数据更新成功<br><br>';
			}else{
				echo '失败<br>'.$DB->error().'<br><br>';
			}
			$etime=microtime(true);//获取程序执行结束的时间
			$total=round($etime-$stime,2);  //计算差值
			echo '社区id='.$sq['id'].'，类型='.$sq['type'].'，订单ID='.$ds_id.'，'.($t==0?'':'货源站已退单' .$t. '个，').'耗时='.$total.'秒<br><br>';
			$t=0;
		}
	$n++;
	}
}

$etime=microtime(true);//获取程序执行结束的时间
$total=round($etime-$stime2,2);  //计算差值
echo '本次更新订单数量'.$n.'<br><br>';
echo '一共耗时='.$total.'秒<br><br><hr>'.$alert;
?>