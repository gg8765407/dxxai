 <?php
if(preg_match('/Baiduspider/', $_SERVER['HTTP_USER_AGENT']))exit;
if(function_exists("set_time_limit")){
	@set_time_limit(0);
}
if(function_exists("ignore_user_abort")){
	@ignore_user_abort(true);
}
@header('Content-Type: text/html; charset=UTF-8');
$stime2=microtime(true);
include("../../includes/common.php");
include("./function.php");
if(empty($conf['cronkey']))exit("请先设置好监控密钥");
if($conf['cronkey']!=$_GET['key'])exit("监控密钥不正确");
if(isset($_GET['shequ'])){
	$sql = " type = '".daddslashes($_GET['shequ'])."'";
}elseif(isset($_GET['shequid'])){
	$sql = " id = '".intval($_GET['shequid'])."'";
}else{
	$sql = " type in('jiuwu','yile','daishua','shangzhanwl')";
}
$limit=isset($_GET['limit'])?daddslashes($_GET['limit']):3000;
$alert .= '目前支持同步全的社区有<br>
	玖五=jiuwu<br>
	亿乐=yile<br>
	彩虹ds=daishua<br>
	商战网=shangzhanwl';
$alert .= '<br><br>同步全部社区<br>'.$siteurl.'cron.php?key=监控密钥';
$alert .= '<br><br>同步同一种类型的社区<br>'.$siteurl.'cron.php?key=监控密钥&shequ=jiuwu';
$alert .= '<br><br>同指定的社区<br>'.$siteurl.'cron.php?key=监控密钥&shequid=社区id(对接设置-对接站点管理，里可获取社区ID)';
$alert .= '<br><br>根据自己的情况进行监控，也可以分开多个同时监控';

$xbc_djstate = array();
$xbc_start_num = array();
$xbc_now_num = array();
$xbc_end_num = array();
$ds_status = array();
$dsw_id = array();
$dsw_orders_time = array();
$dsw_endtime = array();
$n = 0;
$rs=$DB->query("SELECT * FROM `pre_shequ` WHERE{$sql}");
while($sq = $rs->fetch()){
	$url = ($sq['protocol']==1?'https://':'http://') . $sq['url'];
	$rs2=$DB->query("SELECT a.* FROM ((shua_orders a LEFT JOIN shua_pay b ON a.tradeno = b.trade_no) LEFT JOIN shua_shequ c ON b.shequid = c.id) WHERE b.shequid<>0 AND c.id = '{$sq['id']}' AND a.status in(2,3) ORDER BY a.id DESC LIMIT {$limit}");
	$post = array();
	$idArr = array();
	$ds_idArr = array();
	$i=0;
	$t = 0;
	while($res = $rs2->fetch()){
		if($res['xbc_djstate'] == '等待退款')continue;
		if($sq['type'] == 'jiuwu' || $sq['type'] == 'yile' || $sq['type'] == 'daishua'){
			$idArr[] = $res['djorder'];
			$ds_idArr[$res['djorder']] = $res['id'];
			$i++;
			//echo '社区id='.$sq['id'].'____ds_id='.$res['id'].'<br>';
		}elseif($sq['type'] == 'shangzhanwl'){
			$idArr[] = $res['djorder'];

			$param = array('customerid'=>$sq['username'], 'orderno'=>$res['djorder']);
			$sign = md5($sq['username'] . $sq['password']);
			$param['sign'] = $sign;			
			$post[] = http_build_query($param);
			$ds_idArr[$res['djorder']] = $res['id'];
			$i++;
		
		}
		$n++;
	}
	if(count($ds_idArr) == 0)continue;
	//echo '社区id='.$sq['id'].'____ds_idArr='.count($ds_idArr).'<br>';
	//exit;
	$stime=microtime(true);
	if($sq['type'] == 'daishua' && count($idArr)>0){
		$state = array("待处理", "已完成", "正在处理", "异常", "已退单");
		$ret = dsw_chadan($url,$sq['username'],$sq['password'],implode(',',$idArr),'');
		foreach(json_decode($ret,true) as $v){
			$ds_id = $ds_idArr[$v['id']];
			$djstate = $state[$v['id']];
			if($v['status'] == '4'){
				$djstate = '等待退款';
				$t++;
				$ds_status[] = "WHEN ".$ds_id." THEN '3'";
			}elseif($v['status'] == '1'){
				$ds_status[] = "WHEN ".$ds_id." THEN '1'";
			}else{
				$ds_status[] = "WHEN ".$ds_id." THEN '2'";
			}
			$strtime = Sec1Time($v["endtime"],$date); //订单完成的时间
			$dsw_endtime[] = "WHEN '".$ds_id."' THEN '".$date."'";
			$dsw_orders_time[] = "WHEN '".$ds_id."' THEN '".$strtime['time']."'";
			$xbc_djstate[]= "WHEN ".$ds_id." THEN '".$djstate."'";	//社区 的 订单状态
			$xbc_start_num[] = "WHEN ".$ds_id." THEN '".$v['xbc_start_num']."'";	//初始值
			$xbc_now_num[] = "WHEN ".$ds_id." THEN '".$v['xbc_now_num']."'";		//当前值
			$xbc_end_num[] = "WHEN ".$ds_id." THEN '".($v['xbc_now_num']-$v['xbc_start_num'])."'";		//已执行的数量
			$dsw_id[]=$ds_id;	//代刷网的订单号
		}
		$etime=microtime(true);//获取程序执行结束的时间
		$total=round($etime-$stime,2);  //计算差值
		echo '社区id='.$sq['id'].'，类型='.$sq['type'].'，共有 '.$i.' 个订单，'.($t==0?'':'货源站已退单' .$t. '个，').'耗时='.$total.'秒<br><br>';

	}elseif($sq['type'] == 'shangzhanwl' && count($post)>0){	//商战

		$ret = shangzhan_chadan_xbc($url,$sq['username'],$sq['password'],implode(',',$idArr),'');
		$data = json_decode($ret,true);
		if($data['code'] == 1000){
			foreach ($data['data'] as $v) {
				$ds_id = $ds_idArr[$v['orderno']];
				$djstate = $order_stats[$v['orderstate']];
				if($v['orderstate'] == '4' || $v['orderstate'] == '5'){//退款操作
					$djstate = '等待退款';
					$t++;
					$ds_status[] = "WHEN ".$ds_id." THEN '3'";	//代刷网订单状态 为 异常
				}elseif($v['orderstate'] == '3'){	//设置订单完成
					$ds_status[] = "WHEN ".$ds_id." THEN '1'";	//代刷网订单状态 为 完成
				}else{
					$ds_status[] = "WHEN ".$ds_id." THEN '2'";	//代刷网订单状态 为 正在处理
				}
				$xbc_djstate[]= "WHEN '".$ds_id."' THEN '".$djstate."'";	//订单状态
				$xbc_start_num[] = "WHEN '".$ds_id."' THEN '".$v['start_progress']."'";	//开始直
				$xbc_now_num[] = "WHEN '".$ds_id."' THEN '".$v['current_progress']."'";	//当前值
				$xbc_end_num[] = "WHEN '".$ds_id."' THEN '".($v['current_progress']-$v['start_progress'])."'";		//结束值
				$strtime = Sec1Time(date("Y-m-d H:i:s",$v['submittime']),$date);
				$dsw_endtime[] = "WHEN '".$ds_id."' THEN '".$date."'";
				$dsw_orders_time[] = "WHEN '".$ds_id."' THEN '".$strtime['time']."'";
				$dsw_id[]=$ds_id;	//代刷网的订单号
			}
		}

		/*
		//单个商品获取---多线程
		$urls = $url.'/api.php/Client/orderDetail';
		$param = array('url'=>$urls, 'post'=>$post);
		$ret = duo_curl_shangzhan($param);
		$order_stats = [0=>'未知', 1=>'待处理', 2=>'正在处理', 3=>'交易成功', 4=>'处理失败', 5=>'成功退款', 6=>'订单异常'];
		foreach ($ret as $value) {
			$data = json_decode($value,true);
			if($data['code'] == 1000){
				$data = $data['data'];
				$ds_id = $ds_idArr[$data['orderno']];
				$djstate = $order_stats[$data['orderstate']];
				if($data['orderstate'] == '4' || $data['orderstate'] == '5'){//退款操作
					$djstate = '等待退款';
					$t++;
					$ds_status[] = "WHEN ".$ds_id." THEN '3'";	//代刷网订单状态 为 异常
				}elseif($data['orderstate'] == '3'){	//设置订单完成
					$ds_status[] = "WHEN ".$ds_id." THEN '1'";	//代刷网订单状态 为 完成
				}else{
					$ds_status[] = "WHEN ".$ds_id." THEN '2'";	//代刷网订单状态 为 正在处理
				}
				$xbc_djstate[]= "WHEN '".$ds_id."' THEN '".$djstate."'";	//订单状态
				$xbc_start_num[] = "WHEN '".$ds_id."' THEN '".$data['start_progress']."'";	//开始直
				$xbc_now_num[] = "WHEN '".$ds_id."' THEN '".$data['current_progress']."'";	//当前值
				$xbc_end_num[] = "WHEN '".$ds_id."' THEN '".($data['current_progress']-$data['start_progress'])."'";		//结束值
				$strtime = Sec1Time(date("Y-m-d H:i:s",$data['submittime']),$date);
				$dsw_endtime[] = "WHEN '".$ds_id."' THEN '".$date."'";
				$dsw_orders_time[] = "WHEN '".$ds_id."' THEN '".$strtime['time']."'";
				$dsw_id[]=$ds_id;	//代刷网的订单号
			}
		}*/

		$etime=microtime(true);//获取程序执行结束的时间
		$total=round($etime-$stime,2);  //计算差值
		echo '社区id='.$sq['id'].'，类型='.$sq['type'].'，共有 '.$i.' 个订单，'.($t==0?'':'货源站已退单' .$t. '个，').'耗时='.$total.'秒<br><br>';

	}elseif($sq['type'] == 'jiuwu' && count($idArr)>0){

		$ret = jiuwu_chadan_xbc($url,$sq['username'],$sq['password'],implode(',',$idArr));
		$jiuwu_data_json = json_decode($ret, true);
		foreach($jiuwu_data_json as $v){
			$order_stats = array("未开始", "未开始", "进行中", "已完成", "已退单", "退单中", "续费中", "补单中", "改密中", "登录失败");
			$ds_id = $ds_idArr[$v['id']];
			$djstate = $order_stats[$v['order_state']];
			if($v["order_state"] == '3'){//已完成
				$ds_status[] = "WHEN ".$ds_id." THEN '1'";
			}elseif($v['order_state'] == '4'){	//已退单
				$djstate = '等待退款';
				$t++;
				$ds_status[] = "WHEN ".$ds_id." THEN '3'";
			}else{
				$ds_status[] = "WHEN ".$ds_id." THEN '2'";
			}
			$strtime = Sec1Time($v["add_time"],$date); //订单完成的时间
			$dsw_endtime[] = "WHEN '".$ds_id."' THEN '".$date."'";
			$dsw_orders_time[] = "WHEN '".$ds_id."' THEN '".$strtime['time']."'";
			$xbc_djstate[]= "WHEN ".$ds_id." THEN '".$djstate."'";	//社区 的 订单状态
			$xbc_start_num[] = "WHEN ".$ds_id." THEN '".$v['start_num']."'";	//初始值
			$xbc_now_num[] = "WHEN ".$ds_id." THEN '".$v['now_num']."'";		//当前值
			$xbc_end_num[] = "WHEN ".$ds_id." THEN '".($v['now_num']-$v['start_num'])."'";		//已执行的数量
			$dsw_id[]=$ds_id;	//代刷网的订单号
		}
		$etime=microtime(true);//获取程序执行结束的时间
		$total=round($etime-$stime,2);  //计算差值
		echo '社区id='.$sq['id'].'，类型='.$sq['type'].'，共有 '.$i.' 个订单，'.($t==0?'':'货源站已退单' .$t. '个，').'耗时='.$total.'秒<br><br>';
	}elseif($sq['type'] == 'yile' && count($idArr)>0){

		$order_stats = array(0=>"等待中",1=>"进行中",2=>"退单中",3=>"已退单",4=>"异常中",5=>"补单中",6=>"已更新",90=>"已完成",92=>"已退款");
		$ret = yile_chadan_xbc($url,$sq['username'],$sq['password'],implode(',',$idArr));	//社区域名、账号、密码、订单号
		foreach($ret as $v){
			$ds_id = $ds_idArr[$v['id']];
			$djstate = $order_stats[$v['id']];
			if($v["status"] == '90'){//已完成
				$ds_status[] = "WHEN ".$ds_id." THEN '1'";
			}elseif($v["status"] == '92'){
				$djstate = '等待退款';
				$t++;
				$ds_status[] = "WHEN ".$ds_id." THEN '3'";
			}else{
				$ds_status[] = "WHEN ".$ds_id." THEN '2'";
			}
			$strtime = Sec1Time($v["created_at"],$date); //订单完成的时间
			$dsw_endtime[] = "WHEN '".$ds_id."' THEN '".$date."'";
			$dsw_orders_time[] = "WHEN '".$ds_id."' THEN '".$strtime['time']."'";
			$xbc_djstate[]= "WHEN ".$ds_id." THEN '".$djstate."'";	//社区 的 订单状态
			$xbc_start_num[] = "WHEN ".$ds_id." THEN '".$v['start_num']."'";	//初始值
			$xbc_now_num[] = "WHEN ".$ds_id." THEN '".$v['now_num']."'";		//当前值
			$xbc_end_num[] = "WHEN ".$ds_id." THEN '".($v['now_num']-$v['start_num'])."'";		//已执行的数量
			$dsw_id[]=$ds_id;	//代刷网的订单号
		}
		$etime=microtime(true);//获取程序执行结束的时间
		$total=round($etime-$stime,2);  //计算差值
		echo '社区id='.$sq['id'].'，类型='.$sq['type'].'，共有 '.$i.' 个订单，'.($t==0?'':'货源站已退单' .$t. '个，').'耗时='.$total.'秒<br><br>';
	}
}


if(count($dsw_id > 0)){
	$sql = "UPDATE shua_orders 
		SET xbc_djstate = CASE id 
			".implode(' ',$xbc_djstate)."
		END, 
		xbc_start_num = CASE id 
			".implode(' ',$xbc_start_num)."
		END, 
		xbc_now_num = CASE id 
			".implode(' ',$xbc_now_num)."
		END, 
		xbc_end_num = CASE id 
			".implode(' ',$xbc_end_num)."
		END,
		status = CASE id 
			".implode(' ',$ds_status)."
		END,
		endtime = CASE id 
			".implode(' ',$dsw_endtime)."
		END,
		xbc_orders_time = CASE id 
			".implode(' ',$dsw_orders_time)."
		END
	WHERE id IN (".implode(',',$dsw_id).")";
	if(empty($dsw_id))exit('没有订单需要同步的<br><hr>'.$alert);
	if($DB->exec($sql)){
		echo '订单数据更新成功<br><br>';
	}else{
		echo '失败<br>'.$DB->error().'<br><br>';
	}
}

$etime=microtime(true);//获取程序执行结束的时间
$total=round($etime-$stime2,2);  //计算差值
echo '本次更新订单数量'.$n.'<br><br>';
echo '一共耗时='.$total.'<br><br><hr>'.$alert;
?>