<?php
//直客 查单
function zhike_chadan($url,$user,$pwd,$orderid){
    $path = '/api/client/goods/v2/order?orderSN='.$orderid;
    $url = $url.$path;
    $time = time();
    $token = sha1($user.$pwd.$path.$time);
    $header = ['AppId: '.$user, 'AppToken: '.$token, 'AppTimestamp: '.$time];
    if($post){
        $header[] = 'Content-Type: application/json; charset=UTF-8';
    } 
    $data = shequ_get_curl_xbc($url,$post,0,0,$header);
    return $data;
}
 //代刷网
function dsw_chadan($url,$user,$pwd,$id,$status){
    $url = $url.'/api_tool/api/api.php?act=search';
    $param = array('user'=>$user, 'pass'=>$pwd, 'id'=>$id, 'status'=>$status);
    $post = http_build_query($param);
    $data = get_curl($url,$post);
    return $data;
    
}
//商战查询订单----单个商品查询
function shangzhan_chadan_row($url,$user,$pwd,$orderno){
    $url = $url.'/api.php/Client/orderDetail';
    $order_stats = [0=>'未知', 1=>'待处理', 2=>'正在处理', 3=>'交易成功', 4=>'处理失败', 5=>'成功退款', 6=>'订单异常'];
    $param = array('customerid'=>$user, 'orderno'=>$orderno);
    $sign = md5($user . $pwd);
    $param['sign'] = $sign;
    $post = http_build_query($param);
    $data = get_curl($url,$post);
    return $data;
    
}
//商战查询订单
function shangzhan_chadan_xbc($url,$user,$pwd,$orderno){
    $url = $url.'/api.php/Client/getOrderList';
    $param = array('customerid'=>$user, 'orderno'=>$orderno);
    $sign = md5($user . $pwd);
    $param['sign'] = $sign;
    $post = http_build_query($param);
    $data = get_curl($url,$post);
    return $data;
}
function jiuwu_chadan_xbc($squrl,$user,$pass,$orders){//社区域名、账号、密码、订单号
    $url = $squrl . "/index.php?m=Home&c=Order&a=query_orders_detail";
    $post = "Api_UserName=" . urlencode($user) . "&Api_UserMd5Pass=" . md5($pass) . "&return_fields=id%2Cneed_num_0%2Cstart_num%2Cend_num%2Cnow_num%2Corder_state%2Clogin_state%2Cstart_time%2Cend_time%2Cadd_time&orders_id=" . $orders;
    $data=get_curl($url, $post);

    if (!($data_json = json_decode($data, true))) {
        return false;
    }
    if ($data_json["status"] == true) {
        return json_encode($data_json["rows"]);
    }
    return $data_json["info"];
}


function yile_chadan_xbc($url, $user, $pass, $orders){  //社区域名、账号、密码、订单号
    $_var_4 = array(0 => "等待中", 1 => "进行中", 2 => "退单中", 3 => "已退单", 4 => "异常中", 5 => "补单中", 6 => "已更新", 90 => "已完成", 91 => "已退款");
    $_var_5 = $url . "/api/order/query";
    $_var_6 = array("api_token" => $user, "timestamp" => time(), "ids" => $orders);
    $_var_7 = yile_getSign($_var_6, $pass);
    $_var_6["sign"] = $_var_7;
    $_var_8 = http_build_query($_var_6);
    $_var_9 = get_curl($_var_5, $_var_8);
    
    
    if (!($_var_9 = json_decode($_var_9, true))) {
        return false;
    }
    if ($_var_9["status"] !== 0) {
        return $_var_9["message"];
    }
    return $_var_9["data"];
}

//时间计算
function Sec1Time($startdate,$enddate){
    $time= strtotime($enddate) - strtotime($startdate);
    if(is_numeric($time)){
        $str = '';
        $value = array("years" => 0, "days" => 0, "hours" => 0,"minutes" => 0, "seconds" => 0, "time" => 0);
        if($time >= 31556926){
            $value["years"] = floor($time/31556926);
            $str.= $value['years'].'年';
            $time = ($time%31556926);
        }
        if($time >= 86400){
            $value["days"] = floor($time/86400);
            $str.= $value['days'].'天';
            $time = ($time%86400);
        }
        if($time >= 3600){
            $value["hours"] = floor($time/3600);
            $str.= $value['hours'].'时';
            $time = ($time%3600);
        }
        if($time >= 60){
            $value["minutes"] = floor($time/60);
            $str.= $value['minutes'].'分';
            $time = ($time%60);
        }
        $value["seconds"] = floor($time);
        $str.= $value['seconds'].'秒';
        $value["time"] = $str;
        return $value;
    }else{
        return false; 
    }
}
/**
 * 虚拟多线程Curl
 * @param $urls array 网址列表
 * @return array
 */
function duo_curl_shangzhan($param){
    $ua = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.93 Safari/537.36';
    $queue = curl_multi_init();
    $map = [];
    foreach ($param['post'] as $value) {
    	$url = $param['url'];
        $ch = curl_init();
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_URL, $url);
		if($value){
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $value);
		}
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_USERAGENT, $ua);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_NOSIGNAL, true);
        curl_multi_add_handle($queue, $ch);
        $map[(string)$ch] = $url;
    }
    $responses = [];
    do {
        while (($code = curl_multi_exec($queue, $active)) == CURLM_CALL_MULTI_PERFORM) ;
        if ($code != CURLM_OK) {
            break;
        }
        while ($done = curl_multi_info_read($queue)) {
            $info = curl_getinfo($done['handle']);
            $error = curl_error($done['handle']);
            $results = curl_multi_getcontent($done['handle']);//返回内容
            $responses[] = $results;
            //$responses[$map[(string)$done['handle']]] = compact('info', 'error', 'results');
            curl_multi_remove_handle($queue, $done['handle']);
            curl_close($done['handle']);
        }
        if ($active > 0) {
            curl_multi_select($queue, 0.5);
        }
    } while ($active);
    curl_multi_close($queue);
    return $responses;
}

function duo_curl_zhike($param){
    $ua = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.93 Safari/537.36';
    $queue = curl_multi_init();
    $map = [];
    foreach ($param as $key => $value) {
        $url = $value['url'];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $httpheader[] = "Accept: */*";
        $httpheader[] = "Accept-Encoding: gzip,deflate,sdch";
        $httpheader[] = "Accept-Language: zh-CN,zh;q=0.8";
        $httpheader[] = "Connection: close";
        foreach ($value['header'] as $v) {
            $httpheader[] = $v;
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_USERAGENT, $ua);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_NOSIGNAL, true);
        curl_multi_add_handle($queue, $ch);
        $map[(string)$ch] = $url;
    }

    $responses = [];
    do {
        while (($code = curl_multi_exec($queue, $active)) == CURLM_CALL_MULTI_PERFORM) ;
        if ($code != CURLM_OK) {
            break;
        }
        while ($done = curl_multi_info_read($queue)) {
            $info = curl_getinfo($done['handle']);
            $error = curl_error($done['handle']);
            $results = curl_multi_getcontent($done['handle']);//返回内
            $responses[] = $results;
            //$responses[$map[(string)$done['handle']]] = compact('info', 'error', 'results');
            curl_multi_remove_handle($queue, $done['handle']);
            curl_close($done['handle']);
        }
        if ($active > 0) {
            curl_multi_select($queue, 0.5);
        }
    } while ($active);
    curl_multi_close($queue);
    return $responses;
}
function shequ_get_curl_xbc($url, $post=0, $referer=0, $cookie=0, $httpheader2=0, $header=0, $ua=0, $nobaody=0){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $httpheader[] = "Accept: */*";
    $httpheader[] = "Accept-Encoding: gzip,deflate,sdch";
    $httpheader[] = "Accept-Language: zh-CN,zh;q=0.8";
    $httpheader[] = "Connection: close";
    foreach ($httpheader2 as $value) {
        $httpheader[] = $value;
    }
    curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
    curl_setopt($ch, CURLOPT_TIMEOUT, 35);
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    if ($header) {
        curl_setopt($ch, CURLOPT_HEADER, true);
    }
    if ($cookie) {
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    }
    if($referer){
        if($referer==1){
            curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
        }else{
            curl_setopt($ch, CURLOPT_REFERER, $referer);
        }
    }
    if ($ua) {
        curl_setopt($ch, CURLOPT_USERAGENT, $ua);
    }
    else {
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Linux; U; Android 4.0.4; es-mx; HTC_One_X Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0");
    }
    if ($nobaody) {
        curl_setopt($ch, CURLOPT_NOBODY, 1);
    }
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $ret = curl_exec($ch);
/*    if (curl_getinfo($ch, CURLINFO_HTTP_CODE) == '200') {
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);  // 获取header长度
        $ret = substr($ret, $headerSize);  // 截取掉header
    }*/
    curl_close($ch);
    return $ret;
}

 ?>