 <?php
if(preg_match('/Baiduspider/', $_SERVER['HTTP_USER_AGENT']))exit;
if(function_exists("set_time_limit")){
	@set_time_limit(0);
}
if(function_exists("ignore_user_abort")){
	@ignore_user_abort(true);
}
@header('Content-Type: text/html; charset=UTF-8');
include("../../includes/common.php");
if(empty($conf['cronkey']))exit("请先设置好监控密钥");
if($conf['cronkey']!=$_GET['key'])exit("监控密钥不正确");

$i = 0;
$ret = '';
$rs=$DB->query("SELECT * FROM `pre_orders` WHERE xbc_djstate = '等待退款'");
while($res = $rs->fetch()){
	//先查下订单是否已经退款，避免重复退款
	if($res['status'] == '4' || $res['已经退款'] == '4'){
		$DB->exec("update pre_orders set status='4',xbc_djstate='已经退款' where id='{$res['id']}'");
		$ret .= '用户zid='.$res['zid'].'----订单ID='.$res['id'].'----已经退款过的，不在执行退款操作。<br>';
		continue;
	}
	$count=$DB->getColumn("select count(*) from pre_points where action='退单' AND  bz like '%".$res['id']."%'");
	if($count!=0){
		$DB->exec("update pre_orders set status='4',xbc_djstate='已经退款' where id='{$res['id']}'");
		$ret .= '用户zid='.$res['zid'].'----订单ID='.$res['id'].'----已经退款过的，不在执行退款操作。<br>';
		continue;
	}
	$start_num = $res['xbc_start_num'];
	$now_num = $res['xbc_now_num'];
	$zid = $res['userid']==''?$res['zid']:$res['userid'];

	//如果 订单数据的 初始值、当前值、都是为0 或相同，就执行【全额退款】
	if($start_num == $now_num){
		if($DB->exec("update pre_orders set status='4',xbc_djstate='已经退款' where id='{$res['id']}'")){
			changeUserMoney($zid, $res['money'], true, '退单', '订单(ID'.$res['id'].')已全额退款到余额'.$res['money']);
			$ret .= '用户zid='.$zid.'----订单ID='.$res['id'].'----全额退款，金额='.$res['money'].'元<br>';
			$i++;
		}else{
			$ret .= '用户zid='.$zid.'----订单ID='.$res['id'].'----退款失败'.$DB->error().'元<br>';
		}

	}else{	//下根据剩下没刷的数量进行退款
	
		$tool=$DB->getRow("select * from pre_tools where tid='{$res['tid']}' limit 1");
		$value=$tool['value']>0?$tool['value']:1;
		$value=$res['value']*$value;//下单数量
		$tnum = $start_num + $value - $now_num;//计算出剩下没刷的数量
		$rmb = $res['money'] / $value;//计算出单个点数的价钱
		$trmb = round($rmb * $tnum,5);//计算出退回的金额
		changeUserMoney($zid, $trmb, true, '退单', '订单(ID'.$res['id'].')订单总额:'.$res['money'].',退回剩下点数 '.$tnum.'点');
		$DB->exec("update pre_orders set status='4',xbc_djstate='已经退款' where id='{$res['id']}'");
		$ret .= '用户zid='.$zid.'----订单ID='.$res['id'].'----退部分款，金额='.$res['money'].'元<br>';
		$i++;		
	}
	
	//检查下级提成，并扣除
	$count=$DB->getColumn("SELECT count(*) FROM `pre_points` WHERE action='提成' AND orderid='{$res['id']}'");
	if($count>0){
		$rs2=$DB->query("SELECT * FROM `pre_points` WHERE action='提成' AND orderid='{$res['id']}' ORDER BY id DESC");
/*		$tool = $DB->getRow("SELECT * FROM `shua_tools` WHERE tid='{$res['tid']}' LIMIT 1");
		$value=$tool['value']>0?$tool['value']:1;
		$value=$res['value']*$value;//下单数量
		$tnum = $start_num + $value - $now_num;//计算出剩下没刷的数量*/
		while($res_points = $rs2->fetch()){
			$count=$DB->getColumn("SELECT count(*) FROM pre_points WHERE zid='{$res_points['zid']}' AND  action='扣除' AND  bz like '%单(ID{$res['id']})%'");
			if($count>0)continue;
			if($start_num == $now_num){
				changeUserMoney($res_points['zid'], $res_points['point'], true, '扣除', '订单(ID'.$res['id'].')已退单，扣除提成金额：'.$res_points['point']);
			}else{
				$points = $res_points['point'] / $value;	//点数金额
				$total_points = $points * $tnum;	//总提成 需要扣除的
				$real_points = $res_points['point'] - $total_points;	//真实提成
				changeUserMoney($res_points['zid'], $total_points, true, '扣除', '订单(ID'.$res['id'].')已退单，扣除部分提成金额：'.$total_points.'，实得提成：'.$real_points.'元');
			}
		}
	}
}
if($i == 0)exit('没有订单 需要退款给用户的');
exit($ret);
?>
