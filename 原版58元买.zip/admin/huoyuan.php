<?
include("../includes/common.php");
$title='货源推荐';
/** 授权系统对接 */
			$zbape              = 'http://auth.lianxuncloud.com/api/index/';
			$api                = 'recommend?appid=3&webkey=AnDi_Auth_1969215';
			$zbapi              = $zbape . $api;
			$zbape = curl_init();
			curl_setopt($zbape,CURLOPT_URL,"{$zbapi}");
			curl_setopt($zbape, CURLOPT_SSL_VERIFYPEER, false); //如果USBURL就是https的,我们将其设为不验证,如果不是https的接口,这句可以不必加
			curl_setopt($zbape,CURLOPT_RETURNTRANSFER,true);
			curl_setopt($zbape, CURLOPT_NOSIGNAL, true);
// 			curl_setopt($zbape, CURLOPT_CONNECTTIMEOUT_MS, 500);
// 			curl_setopt($zbape, CURLOPT_TIMEOUT_MS, 500);
			$data = curl_exec($zbape);
			curl_close($zbape);
			$data=json_decode($data,true);//将json格式转化为数组格式,方便使用
			if(is_array($data)){
				foreach($data as $key => $value)
					$key = $value;
//看这个获取需要获取的数据
				$name = $value[0]["webname"];  //名称
				$qq = $value[0]["webqq"];  //QQ号
				$money = $value[0]["money"];  //价格
			}
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<div class="widget">
<div class="widget-content border-bottom">
<span class="pull-right text-muted"><i class="fa fa-shield"></i></span>
货源推荐
</div>
<ul class="list-group">
<?
foreach($data as $key){
    echo '<li class="list-group-item">'.$qq.'</li>';
};
?>
<li class="list-group-item"><?php echo $qq?></li>	</ul>
</div>