<?php
/**
 * 团购记录
**/
include("../includes/common.php");
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
adminpermission('shop', 1);

if(isset($_GET['kw'])){
	$kw = trim(daddslashes($_GET['kw']));
	$sql=" A.`zid`='$kw'";
	$numrows=$DB->getColumn("SELECT count(*) FROM pre_group A LEFT JOIN pre_tools B ON A.tid=B.tid WHERE{$sql}");
	$con='团长ZID <b>'.$kw.'</b> 的共有 <b>'.$numrows.'</b> 条团购记录';
	$link='&kw='.$kw;
}elseif(isset($_GET['gid'])){
	$gid = intval($_GET['gid']);
	$numrows=$DB->getColumn("SELECT count(*) from pre_group where gid='$gid'");
	$sql=" gid='$gid'";
	$con='该商品共有 <b>'.$numrows.'</b> 条团购记录';
	$link='&gid='.$gid;
}else{
	$numrows=$DB->getColumn("SELECT count(*) from pre_group");
	$sql=" 1";
	$con='系统共有 <b>'.$numrows.'</b> 条团购记录';
}
?>
	  <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>ID</th><th>商品名称</th><th>团长ZID</th><th>下单账号</th><th>进度</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
<?php
$pagesize=isset($_GET['num'])?intval($_GET['num']):30;
$pages=ceil($numrows/$pagesize);
$page=isset($_GET['page'])?intval($_GET['page']):1;
$offset=$pagesize*($page - 1);

$rs=$DB->query("SELECT A.*,B.`name` FROM `pre_group` A LEFT JOIN `pre_tools` B ON A.`tid`=B.`tid` WHERE{$sql} ORDER BY A.`id` DESC LIMIT $offset,$pagesize");
while($res = $rs->fetch())
{
	$progress = $res['click'].'/'.$res['plan'];
	if($res['status']==1){
		$status = '<font color="green">已完成</font>';
	}elseif($res['endtime']<$date){
		$status = '<font color="orange">已过期</font>';
	}else{
		$status = '<font color="orange">进行中</font>';
	}
	$input_arr = explode('|',$res['input']);
echo '<tr><td><b>'.$res['id'].'</b></td><td><a href="./shoplist.php?tid='.$res['tid'].'">'.$res['name'].'</a></td><td>'.$res['zid'].'</td><td>'.$input_arr[0].'</td><td>'.$progress.'</td><td>'.$status.'</td><td><span class="btn btn-xs btn-danger" onclick="delGroup('.$res['id'].')">删除</span></td></tr>
';
}
?>
          </tbody>
        </table>
</div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="javascript:void(0)" onclick="listTable(\'page='.$first.$link.'\')">首页</a></li>';
echo '<li><a href="javascript:void(0)" onclick="listTable(\'page='.$prev.$link.'\')">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
$start=$page-10>1?$page-10:1;
$end=$page+10<$pages?$page+10:$pages;
for ($i=$start;$i<$page;$i++)
echo '<li><a href="javascript:void(0)" onclick="listTable(\'page='.$i.$link.'\')">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$end;$i++)
echo '<li><a href="javascript:void(0)" onclick="listTable(\'page='.$i.$link.'\')">'.$i .'</a></li>';
if ($page<$pages)
{
echo '<li><a href="javascript:void(0)" onclick="listTable(\'page='.$next.$link.'\')">&raquo;</a></li>';
echo '<li><a href="javascript:void(0)" onclick="listTable(\'page='.$last.$link.'\')">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
?>
<script>
$("#blocktitle").html('<?php echo $con?>');
</script>