<?php
/**
 * 自助下单系统
**/
include("../includes/common.php");
$title='商品去重';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
$key=$conf['cronkey'];
$url= $_SERVER['HTTP_HOST'];
?>
<style>
@media (max-width:767px){
.showcountl{padding-right: 5px;}
.showcountr{padding-left: 5px;}
}
</style>
<div class="col-xs-12 col-lg-12" style="padding:100px;">
    <?php  
    $y=file_get_contents('http://'.$url.'/cron.php?do=sql&key='.$key.'');

    ?>
    <script>alert('去重成功');</script>
   
    </div>
