<?php
/**
 * 团购商品列表
**/
include("../includes/common.php");
$title='团购商品列表';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
    <div class="col-md-12 center-block" style="float: none;">
<?php

adminpermission('shop', 1);

$my=isset($_GET['my'])?$_GET['my']:null;

$rs=$DB->query("SELECT * FROM pre_class WHERE active=1 order by sort asc");
$select='<option value="0">请选择商品分类</option>';
while($res = $rs->fetch()){
	$select.='<option value="'.$res['cid'].'">'.$res['name'].'</option>';
}

if($my=='add')
{
?>
<div class="block">
<div class="block-title"><h3 class="panel-title">添加团购商品</h3></div>
<div class="">
  <form action="./groupshop.php?my=add_submit" method="post" class="form" role="form">
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			选择商品
		</span>
		<select id="cid" class="form-control"><?php echo $select;?></select>
		<select id="tid" name="tid" class="form-control"></select>
	</div>
  </div>
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			团购设置
		</span>
		<input type="text" id="money" name="money" value="" class="form-control" placeholder="输入单份商品优惠的金额"/>
		<input type="text" id="people" name="people" value="" class="form-control" placeholder="输入达到优惠条件所需人数"/>
	</div>
  </div>
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			最大数量
		</span>
		<input type="number" min="1" name="nummax" value="" class="form-control" placeholder="请输入最大可享受优惠价数量"/>
	</div>
  </div>
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			排序数字
		</span>
		<input type="number" min="1" max="1000" name="sort" value="" class="form-control" placeholder="数字越小越靠前"/>
	</div>
  </div>
	<div class="form-group">
	  <input type="submit" name="submit" value="添加" class="btn btn-primary btn-block"/>
	</div>
  </form>
  <br/><a href="./groupshop.php">>>返回商品列表</a>
</div>
<div class="panel-footer">
<span class="glyphicon glyphicon-info-sign"></span>团购设置说明：<br/>
【优惠金额】组团成功后，每一份商品优惠的金额<br/>
【成团人数】达到优惠条件所需人数<br/>
【最大数量】最大能以该优惠下单多少份商品
</div>
</div>
<script src="<?php echo $cdnpublic?>layer/3.1.1/layer.js"></script>
<script src="assets/js/groupshopedit.js?ver=<?php echo VERSION ?>"></script>
<?php
}
elseif($my=='edit')
{
$id=$_GET['id'];
$row=$DB->getRow("select * from pre_groupshop where id='$id' limit 1");
$toolname=$DB->getColumn("SELECT name FROM pre_tools WHERE tid='{$row['tid']}' LIMIT 1");
?>
<div class="block">
<div class="block-title"><h3 class="panel-title">修改团购商品</h3></div>
<div class="">
  <form action="./groupshop.php?my=edit_submit&id=<?php echo $id; ?>" method="post" class="form" role="form">
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			商品名称
		</span>
		<input type="text" id="tid" value="<?php echo $toolname; ?>" class="form-control" disabled/>
	</div>
  </div>
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			团购设置
		</span>
		<input type="text" id="money" name="money" value="<?php echo $row['money']; ?>" class="form-control" placeholder="输入单份商品优惠的金额"/>
		<input type="text" id="people" name="people" value="<?php echo $row['people']; ?>" class="form-control" placeholder="输入达到优惠条件所需人数"/>
	</div>
  </div>
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			最大数量
		</span>
		<input type="number" min="1" name="nummax" value="<?php echo $row['nummax']; ?>" class="form-control" placeholder="请输入最大可享受优惠价数量"/>
	</div>
  </div>
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			排序数字
		</span>
		<input type="number" min="1" max="1000" name="sort" value="<?php echo $row['sort']; ?>" class="form-control" placeholder="数字越小越靠前"/>
	</div>
  </div>
	<div class="form-group">
	  <input type="submit" name="submit" value="修改" class="btn btn-primary btn-block"/>
	</div>
  </form>
  <br/><a href="./groupshop.php">>>返回商品列表</a>
</div>
<div class="panel-footer">
<span class="glyphicon glyphicon-info-sign"></span>团购设置说明：<br/>
【优惠金额】组团成功后，每一份商品优惠的金额<br/>
【成团人数】达到优惠条件所需人数<br/>
【最大数量】最大能以该优惠下单多少份商品
</div>
</div>
<script src="<?php echo $cdnpublic?>layer/3.1.1/layer.js"></script>
<script src="assets/js/groupshopedit.js?ver=<?php echo VERSION ?>"></script>
<?php
}
elseif($my=='add_submit')
{
$tid=intval($_POST['tid']);
$money=$_POST['money'];
$people=$_POST['people'];
$nummax=$_POST['nummax'];
$sort=$_POST['sort'];
if($money==NULL or $people==NULL or $nummax==NULL or $sort==NULL){
showmsg('保存错误,请确保每项都不为空!',3);
} else {
$sql="insert into `pre_groupshop` (`tid`,`money`,`people`,`nummax`,`sort`,`addtime`,`active`) values ('".$tid."','".$money."','".$people."','".$nummax."','".$sort."','".$date."','1')";
if($DB->exec($sql)!==false){
	showmsg('添加团购商品成功！<br/><br/><a href="./groupshop.php">>>返回团购商品列表</a>',1);
}else
	showmsg('添加团购商品失败！'.$DB->error(),4);
}
}
elseif($my=='edit_submit')
{
$id=$_GET['id'];
$rows=$DB->getRow("select * from pre_groupshop where id='$id' limit 1");
if(!$rows)
	showmsg('当前记录不存在！',3);
$money=$_POST['money'];
$people=$_POST['people'];
$nummax=$_POST['nummax'];
$sort=$_POST['sort'];
if($money==NULL or $people==NULL or $nummax==NULL or $sort==NULL){
showmsg('保存错误,请确保每项都不为空!',3);
} else {
if($DB->exec("UPDATE `pre_groupshop` SET `money`='".$money."',`people`='".$people."',`nummax`='".$nummax."',`sort`='".$sort."' WHERE `id`='".$id."'")!==false)
	showmsg('修改团购商品成功！<br/><br/><a href="./groupshop.php">>>返回团购商品列表</a>',1);
else
	showmsg('修改团购商品失败！'.$DB->error(),4);
}
}
else
{
?>
<div class="block">
<div class="block-title clearfix">
<h2 id="blocktitle"></h2>
<span class="pull-right"><select id="pagesize" class="form-control"><option value="30">30</option><option value="50">50</option><option value="60">60</option><option value="80">80</option><option value="100">100</option></select><span>
</span></span>
</div>
  <form onsubmit="return searchItem()" method="GET" class="form-inline">
  <a href="./groupshop.php?my=add" class="btn btn-primary"><i class="fa fa-plus"></i>&nbsp;添加团购商品</a>
  <div class="form-group">
    <input type="text" class="form-control" name="kw" placeholder="请输入商品名称">
  </div>
  <button type="submit" class="btn btn-info">搜索</button>&nbsp;
  <a href="javascript:listTable('start')" class="btn btn-default" title="刷新商品列表"><i class="fa fa-refresh"></i></a>
</form>
<div id="listTable"></div>
  </div>
</div>
<script src="<?php echo $cdnpublic?>layer/3.1.1/layer.js"></script>
<script src="assets/js/groupshop.js?ver=<?php echo VERSION ?>"></script>
<?php }?>
</body>
</html>