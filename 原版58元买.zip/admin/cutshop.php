<?php
/**
 * 砍价商品列表
**/
include("../includes/common.php");
$title='砍价商品列表';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
    <div class="col-md-12 center-block" style="float: none;">
<?php

adminpermission('shop', 1);

$my=isset($_GET['my'])?$_GET['my']:null;

$rs=$DB->query("SELECT * FROM pre_class WHERE active=1 order by sort asc");
$select='<option value="0">请选择商品分类</option>';
while($res = $rs->fetch()){
	$select.='<option value="'.$res['cid'].'">'.$res['name'].'</option>';
}

if($my=='add')
{
?>
<div class="block">
<div class="block-title"><h3 class="panel-title">添加砍价商品</h3></div>
<div class="">
  <form action="./cutshop.php?my=add_submit" method="post" class="form" role="form">
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			选择商品
		</span>
		<select id="cid" class="form-control"><?php echo $select;?></select>
		<select id="tid" name="tid" class="form-control"></select>
	</div>
  </div>
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			砍价限制
		</span>
		<input type="text" id="cut_min" name="cut_min" value="" class="form-control" placeholder="输入最小可砍金额"/>
		<input type="text" id="cut_max" name="cut_max" value="" class="form-control" placeholder="输入最大可砍金额"/>
	</div>
  </div>
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			坑多多模式
		</span>
		<select id="pit_pattern" name="pit_pattern" class="form-control"><option value="0">关闭</option><option value="1">开启</option></select>
		<input type="text" id="pit_money" name="pit_money" value="" class="form-control" placeholder="输入金额"/>
	</div>
  </div>
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			发放数量
		</span>
		<input type="number" min="1" name="num" value="" class="form-control" placeholder="请输入发放数量"/>
	</div>
  </div>
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			排序数字
		</span>
		<input type="number" min="1" max="1000" name="sort" value="" class="form-control" placeholder="数字越小越靠前"/>
	</div>
  </div>
	<div class="form-group">
	  <input type="submit" name="submit" value="添加" class="btn btn-primary btn-block"/>
	</div>
  </form>
  <br/><a href="./cutshop.php">>>返回商品列表</a>
</div>
<div class="panel-footer">
<span class="glyphicon glyphicon-info-sign"></span>砍价限制说明：<br/>
【最小可砍金额】邀请游客帮砍，帮砍金额不会少于该数值<br/>
【最大可砍金额】邀请游客帮砍，帮砍金额不会超过该数值<br/>
注:坑多多模式不受此限制<br/>
坑多多模式说明：<br/>
和坑多多一样，当商品金额待砍金额等于该数值时，则游客帮砍金额皆为0.01元<br/>
【发放数量】砍价链接任务完成后，可免费领取多少份该商品
</div>
</div>
<script src="<?php echo $cdnpublic?>layer/3.4.0/layer.js"></script>
<script src="assets/js/cutshopedit.js?ver=<?php echo VERSION ?>"></script>
<?php
}
elseif($my=='edit')
{
$id=$_GET['id'];
$row=$DB->getRow("select * from pre_cutshop where id='$id' limit 1");
$toolname=$DB->getColumn("SELECT name FROM pre_tools WHERE tid='{$row['tid']}' LIMIT 1");
?>
<div class="block">
<div class="block-title"><h3 class="panel-title">修改砍价商品</h3></div>
<div class="">
  <form action="./cutshop.php?my=edit_submit&id=<?php echo $id; ?>" method="post" class="form" role="form">
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			商品名称
		</span>
		<input type="text" id="tid" value="<?php echo $toolname; ?>" class="form-control" disabled/>
	</div>
  </div>
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			砍价限制
		</span>
		<input type="text" id="cut_min" name="cut_min" value="<?php echo $row['cut_min']; ?>" class="form-control" placeholder="输入最小可砍金额"/>
		<input type="text" id="cut_max" name="cut_max" value="<?php echo $row['cut_max']; ?>" class="form-control" placeholder="输入最大可砍金额"/>
	</div>
  </div>
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			坑多多模式
		</span>
		<select id="pit_pattern" name="pit_pattern" class="form-control" default="<?php echo $row['pit_pattern']; ?>"><option value="0">关闭</option><option value="1">开启</option></select>
		<input type="text" id="pit_money" name="pit_money" value="<?php echo $row['pit_money']; ?>" class="form-control" placeholder="输入金额"/>
	</div>
  </div>
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			发放数量
		</span>
		<input type="number" min="1" name="num" value="<?php echo $row['num']; ?>" class="form-control" placeholder="请输入发放数量"/>
	</div>
  </div>
  <div class="form-group">
	<div class="input-group">
		<span class="input-group-addon">
			排序数字
		</span>
		<input type="number" min="1" max="1000" name="sort" value="<?php echo $row['sort']; ?>" class="form-control" placeholder="数字越小越靠前"/>
	</div>
  </div>
	<div class="form-group">
	  <input type="submit" name="submit" value="修改" class="btn btn-primary btn-block"/>
	</div>
  </form>
  <br/><a href="./cutshop.php">>>返回商品列表</a>
</div>
<div class="panel-footer">
<span class="glyphicon glyphicon-info-sign"></span>砍价限制说明：<br/>
【最小可砍金额】邀请游客帮砍，帮砍金额不会少于该数值<br/>
【最大可砍金额】邀请游客帮砍，帮砍金额不会超过该数值<br/>
注:坑多多模式不受此限制<br/>
坑多多模式说明：<br/>
和坑多多一样，当商品金额待砍金额等于该数值时，则游客帮砍金额皆为0.01元<br/>
【发放数量】砍价链接任务完成后，可免费领取多少份该商品
</div>
</div>
<script src="<?php echo $cdnpublic?>layer/3.4.0/layer.js"></script>
<script src="assets/js/cutshopedit.js?ver=<?php echo VERSION ?>"></script>
<?php
}
elseif($my=='add_submit')
{
$tid=intval($_POST['tid']);
$cut_min=$_POST['cut_min'];
$cut_max=$_POST['cut_max'];
$pit_pattern=intval($_POST['pit_pattern']);
$pit_money=$_POST['pit_money'];
$num=$_POST['num'];
$sort=$_POST['sort'];
if($cut_min==NULL or $cut_max==NULL or $num==NULL or $sort==NULL){
showmsg('保存错误,请确保每项都不为空!',3);
} else {
$sql="insert into `pre_cutshop` (`tid`,`cut_min`,`cut_max`,`pit_pattern`,`pit_money`,`num`,`sort`,`addtime`,`active`) values ('".$tid."','".$cut_min."','".$cut_max."','".$pit_pattern."','".$pit_money."','".$num."','".$sort."','".$date."','1')";
if($DB->exec($sql)!==false){
	showmsg('添加砍价商品成功！<br/><br/><a href="./cutshop.php">>>返回砍价商品列表</a>',1);
}else
	showmsg('添加砍价商品失败！'.$DB->error(),4);
}
}
elseif($my=='edit_submit')
{
$id=$_GET['id'];
$rows=$DB->getRow("select * from pre_cutshop where id='$id' limit 1");
if(!$rows)
	showmsg('当前记录不存在！',3);
$cut_min=$_POST['cut_min'];
$cut_max=$_POST['cut_max'];
$pit_pattern=intval($_POST['pit_pattern']);
$pit_money=$_POST['pit_money'];
$num=$_POST['num'];
$sort=$_POST['sort'];
if($cut_min==NULL or $cut_max==NULL or $num==NULL or $sort==NULL){
showmsg('保存错误,请确保每项都不为空!',3);
} else {
if($DB->exec("UPDATE `pre_cutshop` SET `cut_min`='".$cut_min."',`cut_max`='".$cut_max."',`pit_pattern`='".$pit_pattern."',`pit_money`='".$pit_money."',`num`='".$num."',`sort`='".$sort."' WHERE `id`='".$id."'")!==false)
	showmsg('修改砍价商品成功！<br/><br/><a href="./cutshop.php">>>返回砍价商品列表</a>',1);
else
	showmsg('修改砍价商品失败！'.$DB->error(),4);
}
}
else
{
?>
<div class="block">
<div class="block-title clearfix">
<h2 id="blocktitle"></h2>
<span class="pull-right"><select id="pagesize" class="form-control"><option value="30">30</option><option value="50">50</option><option value="60">60</option><option value="80">80</option><option value="100">100</option></select><span>
</span></span>
</div>
  <form onsubmit="return searchItem()" method="GET" class="form-inline">
  <a href="./cutshop.php?my=add" class="btn btn-primary"><i class="fa fa-plus"></i>&nbsp;添加砍价商品</a>
  <div class="form-group">
    <input type="text" class="form-control" name="kw" placeholder="请输入商品名称">
  </div>
  <button type="submit" class="btn btn-info">搜索</button>&nbsp;
  <a href="javascript:listTable('start')" class="btn btn-default" title="刷新商品列表"><i class="fa fa-refresh"></i></a>
</form>
<div id="listTable"></div>
  </div>
</div>
<script src="<?php echo $cdnpublic?>layer/3.4.0/layer.js"></script>
<script src="assets/js/cutshop.js?ver=<?php echo VERSION ?>"></script>
<?php }?>
</body>
</html>