<?php
/**
 * 后台>管理
**/
include("../includes/common.php");
$title='后台管理';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">

<?php

$mod=isset($_GET['mod'])?$_GET['mod']:null;

?>

<?php
if($mod=='cron'){
adminpermission('shopset', 1);
?>
<div class="block">
<div class="block-title"><h3 class="panel-title">计划任务配置</h3></div>
<div class="">
  <form onsubmit="return saveSetting(this)" method="post" class="form-horizontal" role="form">
    <div class="form-group">
	  <label class="col-sm-3 control-label">监控密钥</label>
	  <div class="col-sm-9"><input type="text" name="cronkey" value="<?php echo $conf['cronkey'];?>" class="form-control" placeholder=""/></div>
	</div>
	<div class="form-group">
	  <div class="col-sm-offset-3 col-sm-9"><input type="submit" name="submit" value="修改" class="btn btn-primary btn-block"/>
	 </div>
	</div>
  </form>
</div>
</div>
<div class="block">
<div class="block-title"><h3 class="panel-title">计划任务列表</h3></div>
<div class="">
<p>团购状态检测：</p>
<li class="list-group-item"><?php echo $siteurl?>cron.php?do=group_updatestatus&amp;key=<?php echo $conf['cronkey'];?></li>
</br/>
</div>
</div>
<?php
}elseif($mod=='cutshop'){
adminpermission('shopset', 1);
?>
<div class="block">
<div class="block-title"><h3 class="panel-title">砍价链接设置</h3></div>
<div class="">
  <form onsubmit="return saveSetting(this)" method="post" class="form" role="form">
	<div class="form-group">
	  <label>开启砍价链接功能</label>
	  <select class="form-control" name="cutshop_open" default="<?php echo $conf['cutshop_open'];?>"><option value="0">关闭</option><option value="1">开启</option></select>
	</div>
	<div class="form-group">
	  <label>广告语自定义</label>
	  <textarea class="form-control" name="cutshop_content" rows="5" style="width:100%;"><?php echo htmlspecialchars($conf['cutshop_content']);?></textarea>
	  <pre>其中，商品名称用[name]，砍价链接用[url]，会自动替换</pre>
	</div>
	<div class="form-group">
	  <input type="submit" name="submit" value="修改" class="btn btn-primary btn-block"/><br/>
	  <a href="./cutshop.php" class="btn btn-info btn-block">进入砍价商品列表</a><br/>
	  <a href="./cutlog.php" class="btn btn-default btn-block">查看砍价记录</a>
	</div>
  </form>
</div>
<div class="panel-footer">
<span class="glyphicon glyphicon-info-sign"></span>
砍价链接生成地址：/?mod=cutshop<br/>
砍价页面模板文件：/template/default/cutshop.php<br/>
如果启用砍价商城，建议先设置好<a href="./set.php?mod=captcha">用户IP地址获取设置</a>，相同IP地址只能帮砍一次。
</div>
</div>
<?php
}elseif($mod=='groupshop'){
adminpermission('set', 1);
?>
<div class="block">
<div class="block-title"><h3 class="panel-title">团购链接设置</h3><div class="block-options pull-right"><a class="btn btn-default" href="groupjk.php">团购状态监控</a></div></div>
<div class="">
  <form onsubmit="return saveSetting(this)" method="post" class="form" role="form">
	<div class="form-group">
	  <label>开启团购链接功能</label>
	  <select class="form-control" name="groupshop_open" default="<?php echo $conf['groupshop_open'];?>"><option value="0">关闭</option><option value="1">开启</option></select>
	</div>
	<div class="form-group">
	  <label>广告语自定义</label>
	  <textarea class="form-control" name="groupshop_content" rows="5" style="width:100%;"><?php echo htmlspecialchars($conf['groupshop_content']);?></textarea>
	  <pre>其中，商品名称用[name]，团购链接用[url]，会自动替换</pre>
	</div>
	<div class="form-group">
	  <input type="submit" name="submit" value="修改" class="btn btn-primary btn-block"/><br/>
	  <a href="./groupshop.php" class="btn btn-info btn-block">进入团购商品列表</a><br/>
	  <a href="./grouplog.php" class="btn btn-default btn-block">查看团购记录</a>
	</div>
  </form>
</div>
<div class="panel-footer">
<span class="glyphicon glyphicon-info-sign"></span>
团购链接生成地址：/?mod=groupshop<br/>
团购页面模板文件：/template/default/groupshop.php
</div>
</div>
<script>
function saveMap(obj) {
	var map_urlpattern = $("input[name='map_urlpattern']").val();
	if(map_urlpattern.indexOf('http')>=0){
		var ii = layer.load(2, {shade:[0.1,'#fff']});
		$.ajax({
			type : 'POST',
			url : 'ajax.php?act=map',
			data : $(obj).serialize(),
			dataType : 'json',
			success : function(data) {
				layer.close(ii);
				if(data.code == 0){
					layer.msg(data.msg);
				}else{
					layer.alert(data.msg);
				}
			} ,
			error:function(data){
				layer.close(ii);
				layer.msg('目标URL连接超时');
				return false;
			}
		});
	}else{
		layer.alert('URL规则必须以 http:// 开头，以 / 结尾');
	}
	return false;
}
</script>
<?php }?>
<script src="<?php echo $cdnpublic?>layer/3.4.0/layer.js"></script>
<script>
var items = $("select[default]");
for (i = 0; i < items.length; i++) {
	$(items[i]).val($(items[i]).attr("default")||0);
}
function saveSetting(obj){
	if($("input[name='fenzhan_domain']").length>0){
		var fenzhan_domain = $("input[name='fenzhan_domain']").val();
		$("input[name='fenzhan_domain']").val(fenzhan_domain.replace("，",","));
	}
	if($("input[name='fenzhan_remain']").length>0){
		var fenzhan_remain = $("input[name='fenzhan_remain']").val();
		$("input[name='fenzhan_remain']").val(fenzhan_remain.replace("，",","));
	}
	var ii = layer.load(2, {shade:[0.1,'#fff']});
	$.ajax({
		type : 'POST',
		url : 'ajax.php?act=set',
		data : $(obj).serialize(),
		dataType : 'json',
		success : function(data) {
			layer.close(ii);
			if(data.code == 0){
				layer.alert('设置保存成功！', {
					icon: 1,
					closeBtn: false
				}, function(){
				  window.location.reload()
				});
			}else{
				layer.alert(data.msg, {icon: 2})
			}
		},
		error:function(data){
			layer.msg('服务器错误');
			return false;
		}
	});
	return false;
}
</script>
    </div>
  </div>