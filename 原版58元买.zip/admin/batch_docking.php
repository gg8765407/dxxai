<?php
/**
 * 社区/卡盟对接日志
**/
include("../includes/common.php");
$title='批量对接商品';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
$option = '<option value="-1">--请选择对接社区--</option>';
$option2 = '';
$re=$DB->query("SELECT * FROM `pre_shequ` WHERE type in('jiuwu','yile','zhike')");
while($res = $re->fetch()){
    if($res['type'] == 'jiuwu'){
        $type = '玖伍';
    }elseif($res['type'] == 'yile'){
        $type = '亿乐';
    }elseif($res['type'] == 'zhike'){
        $type = '直客';
    }elseif($res['type'] == 'shangzhanwl'){
        $type = '商战网';
    }else{
        $type = '未知';
    }
    $option .= '<option value="'.$res['id'].'" type="'.$res['type'].'">'.($res['remark']==''?'':$res['remark'].'_').$res['url'].'_'.$type.'</option>';
}
?>

<div class="col-md-12 col-lg-10 center-block" style="float: none;">
    <div class="block">
        <div class="block-title"><h2>批量对接商品</h2></div>
        目前支持、玖伍、亿乐、直客
        <form action="?" role="form">
            <div class="form-group">
                <select class="form-control" id="is">
                    <option value="0">获取 社区 所有的商品</option>
                    <option value="1">只获取 不存在本系统 的社区商品</option>
                </select>
            </div>

            <div class="form-group">
                <div class="input-group"><div class="input-group-addon">当前对接站点</div>
                    <select class="form-control" id="shequ" onchange="getgoods();">
                        <?php echo $option?>
                    </select>    
                </div>
            </div>
            <div class="form-group" id="showcid" style="display: none;">
                <div class="input-group"><div class="input-group-addon">商品目录</div>
                    <input type="text" class="form-control" id="goodscid" placeholder="输入 全部 就获取全部">
                    <span class="input-group-btn"><a onclick="getgoods()" class="btn btn-default">获取</a></span>  
                </div>
            </div>

            
            <div class="table-responsive">
                <table class="table table-bordered table-vcenter table-hover" id="shoptable">
                    <p id="showtype" style="display:none;"></p>
                    <tbody id="shoplist">
                    </tbody>
                </table>
            </div>

            <div class="form-group">
                <div class="input-group"><div class="input-group-addon">选择保存到本站的分类</div>
                    <select class="form-control" id="mcid">
                        <option value="-1">--请选择分类商品--</option>
                        <option value="0">未分类商品</option>
                        <?php 
                            $re=$DB->query("SELECT * FROM `pre_class`");
                            while($res = $re->fetch()){
                                echo '<option value="'.$res['cid'].'">'.$res['name'].'</option>';
                            }
                        ?>
                    </select>    
                </div>
            </div>

            <div class="form-group">
                <div class="input-group"><div class="input-group-addon">选择加价模板</div>
                    <select class="form-control" id="prid">
                        <option value="-1">--请选择加价模板--</option>
                        <option value="0">不是使用</option>
                        <?php 
                            $re=$DB->query("SELECT * FROM `pre_price`");
                            while($res = $re->fetch()){
                                echo '<option value="'.$res['id'].'">'.$res['name'].'('.$res['p_2'].'元|'.$res['p_1'].'元|'.$res['p_0'].'元)</option>';
                            }
                        ?>
                    </select>
                    <span class="input-group-btn"><a href="./price.php" class="btn btn-default">加价模板管理</a></span>
                </div>
            </div>

            <p><input type="button" name="submit" value="确定添加/更新选中商品" class="btn btn-primary btn-block" id="add_submit"></p>
        </form>   
    
    </div>

    <div class="block">
        <div class="block-title"><h2>初始化商品</h2></div>
        <p>商品图片、商品介绍、下单参数</p>

        <div class="form-group">
            <div class="input-group"><div class="input-group-addon">初始化商品</div>
                <select class="form-control" id="shequ2">
                    <?php echo $option?>
                </select>
                <span class="input-group-btn"><a onclick="getGoodsParam()" class="btn btn-default">初始化</a></span> 
            </div>
        </div>
        
    </div>

</div>

<script src="<?php echo $cdnpublic?>layer/3.1.1/layer.js"></script>
<script>

    var shoplist;
    function getgoods(){
        var shequ = $('#shequ option:selected').val();
        var type = $('#shequ option:selected').attr('type');
        var goodscid = $('#goodscid').val();
        $('#showcid').hide();
        if(shequ == -1){
            return false;
        }else if(type == 'shangzhanwl'){
            $('#showcid').show();
            if(goodscid == ''){
                 return false;
            }else if(goodscid == '全部'){
                 
            }
        }
        var is = $('#is option:selected').val();
        var ii = layer.load(2, {shade:[0.1,'#fff']});
        $("#shoplist").empty();
        $("#showtype").empty();
        $("#shoplist").append('<tr><td><label class="csscheckbox csscheckbox-primary">全选<input type="checkbox" onclick="SelectAll(this)"><span></span></label>&nbsp;商品名称</td><td>成本价</td><td>计算后的价钱</td><td>最少下单数量</td><td>最大下单数量</td><td style="color:red">默认下单数量</td><td>状态</td></tr>');
        shoplist = new Array();
        $.ajax({
            type : "POST",
            url : "./ajax_batch_docking.php?act=getGoodsList",
            data : {shequ:shequ, is:is, type:type, goodscid:goodscid},
            dataType : 'json',
            success : function(data) {

                layer.close(ii);
                if(data.code == 0){

                    $("#showtype").html("社区版的彩虹系统、亿乐、直客系统【默认下单数量】无需填写，直接选择对接即可。<br><br>不是的话【<font color='red'>默认下单数量</font>】根据自己的需求填写，【<font color='red'>计算后的价钱</font>】必需大于0.01元,否者会变成免费的商品。。。<br>不过呢，等导入后社区商品后，您可以挨个的设置【<font color='red'>默认下单数量</font>】这样子是比较麻烦的！");
                   $("#showtype").show();
                   
                    var num = 0;
                    $.each(data.data, function (i, item) {
                        var cost = getFloat(item.price * item.minnum,2);
                        shoplist[item.id] = JSON.stringify(item);
                        $("#shoplist").append('<tr><td><label class="csscheckbox csscheckbox-primary"><input name="tid[]" type="checkbox" class="shop" id="tid" value="'+item.id+'"><span></span>&nbsp;'+item.name+'<label></label></label></td><td><span id="price'+item.id+'">'+item.price+'</span></td><td><span id="cost'+item.id+'">'+cost+'</span></td><td>'+item.minnum+'</td><td>'+item.maxnum+'</td><td><input type="text" class="form-control input-sm" style="width:60px;" id="defaultnum'+item.id+'" value="'+item.minnum+'" onkeyup="changeNum('+item.id+')" required=""></td><td>'+(item.close==1?'<span class="label label-warning">已下架</span>':'<span class="label label-success">上架中</span>')+'</td></tr>');
                        num++;
                    });
                    if(num==0)layer.msg('该分类下没有商品', {icon:0, time:800});
                    else $("#newclass").html("--新建分类【"+$("#cid option:selected").html()+"】--");
                }else{
                    layer.alert(data.msg, {icon:2});
                }
            },
            error:function(data){
              layer.close(ii);
              layer.alert('请求出错'+data);
            }
        });
    }
$(document).ready(function(){
    $("#add_submit").click(function () {

        var shequ = $('#shequ').val();
        var mcid = $("#mcid").val();
        var prid = $("#prid").val();
        if(mcid == -1){
            layer.alert('请选择保存到本站的分类');return false;
        }
        if(prid == -1){
            layer.alert('请选择使用的加价模板');return false;
        }

        var defaultnum = new Array();
        var newshoplist = new Array();
        var items = $('.shop');
        for (i = 0; i < items.length; i++) {
            if (items[i].id.indexOf("tid") != -1 && items[i].type == "checkbox" && items[i].checked == true) {
                var tid = items[i].value;
                newshoplist.push(shoplist[tid]);

                var num = $('#defaultnum'+items[i].value).val();
                defaultnum.push('{"id":"'+items[i].value+'","value":"'+num+'"}');

            }
        }
        if(newshoplist.length <= 0){
            layer.alert('请至少选中一个商品');return false;
        }

        var ii = layer.load(2, {shade:[0.1,'#fff']});
        $.ajax({
            type : "POST",
            url : "ajax_batch_docking.php?act=batchaddgoods",
            dataType : 'json',
            data : {shequ:shequ, mcid:mcid, prid:prid, list:newshoplist, numlist:defaultnum},
            success : function(data) {
                layer.close(ii);
                if(data.code == 0){
                    layer.alert(data.msg);
                }else{
                    layer.alert(data.msg, {icon:2});
                }
            },
            error:function(data){
                layer.msg('加载失败，请刷新重试');
                return false;
            }
        });
    });
})
function getGoodsParam(){
    var shequ = $('#shequ2').val();
    if(shequ == -1){
        layer.alert('请选择社区');return false;
    }
    layer.open({
        title: '执行的数量',
        content: '由于每个社区访问速度不一样，如果数量过多会超时的。<br><div class="input-group"> <span class="input-group-addon">执行数量</span><select id="count" class="form-control"><option value="1">1</option><option value="10">10</option><option value="20">20</option><option value="30">30</option><option value="50">50</option><option value="100">100</option><option value="200">200</option><option value="1000">全部</option></select></div>',
        btn:['确定','取消'],
        yes:function(index,layero){
            var count = $('#count').val();
            var ii = layer.load(2, {shade:[0.1,'#fff']});
            $.ajax({
                type : "POST",
                url : "ajax_batch_docking.php?act=getGoodsParam",
                dataType : 'json',
                data : {shequ:shequ,count:count},
                success : function(data) {
                    layer.close(ii);
                    if(data.code == 0){
                        layer.alert(data.msg);
                    }else{
                        layer.alert(data.msg, {icon:2});
                    }
                },
                error:function(data){
                    layer.close(ii);
                    layer.msg('加载失败，请刷新重试');
                    return false;
                }
            });            
        }
    });


}
function SelectAll(chkAll) {
    var items = $('.shop');
    for (i = 0; i < items.length; i++) {
        if (items[i].id.indexOf("tid") != -1 && items[i].type == "checkbox") {
            items[i].checked = chkAll.checked;
        }
    }
}
function getFloat(number, n) {
    n = n ? parseInt(n) : 0;
    if (n <= 0) return Math.ceil(number);
    number = Math.round(number * Math.pow(10, n)) / Math.pow(10, n);
    return number;
}
function changeNum(id){
    var price = $("#price"+id).html();
    var num = $("#defaultnum"+id).val();
    $("#cost"+id).html(getFloat(num * price, 2));
    
}  
</script>

    </div>
</div>