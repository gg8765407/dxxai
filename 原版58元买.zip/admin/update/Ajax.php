<?php
/*
 * // +--------------------------------------------+
 * // | Name: AnDi_Auth_1969215-在线更新SDK
 * // +--------------------------------------------+
 * // | Author: Nathan<www.nanyinet.com>
 * // +--------------------------------------------+
 * // | Contact: QQ：2322796106
 * // +--------------------------------------------+
 * // | Created: PHPStorm
 * // +--------------------------------------------+
 * // | Date: 2022年12月30日
 * // +--------------------------------------------+
 * // | Tips: 此文件为AnDi_Auth_1969215的在线更新SDK
 * // | 请勿盗用与其他授权系统
 * // | 如有不会写在线更新的，可联系 Nathan 付费代写
 * // +--------------------------------------------+
 */
 
include 'Common/common.php';
$act=isset($_GET['act'])?addslashes($_GET['act']):null;
switch($act) {
    case 'update':
        $data_url = json_decode(curl_request('https://auth.lianxuncloud.com/api/Index/version?appid=3&url='.$_SERVER['HTTP_HOST'].'&authcode='.$auth['authcode'].'&webkey=AnDi_Auth_1969215'),true);
        if ($data_url['version'] > $auth['app_version']){
            nathan_json('1','有新版本 V '.$data_url['version'],'<li class="list-group-item">程序：<b> '.$data_url['appname'].' </b></li>
<li class="list-group-item">版本：<b> V '.$data_url['version'].' </b></li>
<li class="list-group-item">发布时间：<b> '.$data_url['date'].' </b></li>
<li class="list-group-item">更新内容：<p><b> '.$data_url['content'].' </b></li></p>');
        }elseif ($data_url['version'] == $auth['app_version']){
            nathan_json('0','当前已经是最新版本');
        }else {
            nathan_json('0','更新检测错误，请联系上级处理');
        }
        break;
    case 'updfile':
        $data_url = json_decode(curl_request('https://auth.lianxuncloud.com/api/Index/version?appid=3&url='.$_SERVER['HTTP_HOST'].'&authcode='.$auth['authcode'].'&webkey=AnDi_Auth_1969215'),true);
        $token = addslashes($_POST['token']);
        if ($token === 'Nathan'){
            if (!function_exists('zip_open')) {
                nathan_json('0','不支持zip_open，请尝试切换php版本');
            }
            $oldVid = $auth['app_version'];
            if ($oldVid === $data_url['version']) {
                nathan_json('0','当前版本无需更新');
            }
            if ($oldVid > $data_url['version']) {
                nathan_json('0','新版版本号错误');
            }
            $dir = 'update/' . md5('id_' . $data_url['version']) .'/';
            $zipFile = $dir . 'sourceCode.zip';
            if ((!is_dir($dir)) and (!mkdir($dir, 0777, true))) {
                nathan_json('0','下载不存在并且无法创建');
            }
            $res = getCurl($data_url['update_zip'],'', $header);
            if (!$res[0]) {
                return $res;
            }
            $save = @file_put_contents($zipFile, $res[1]);
            if (!$save) {
                nathan_json('0','写入文件失败');
            }
            $zip = new ZipArchive();
            if($zip->open($zipFile) && $zip->extractTo(ROOT)){
                $zip->close($zipFile);
                delete_dir_file('update/');
                if ($data_url['update_sql']) {
                    $list = array_filter(explode(';',$data_url['update_sql']));
                    foreach ($list as $sql) {
                        if (!$sql || $sql[0] == '#') {
                            continue;
                        }
                        $DB->query($sql);
                    }
                }
                nathan_json('1','更新成功，欢迎使用^_^');
            }else{
                nathan_json('0','解压失败');
            }
        }else{
            nathan_json('0','非法请求');
        }
        break;
    case 'Check_Auth':
        $Auth_Url = file_get_contents('https://auth.lianxuncloud.com/api/Index/query_auth?appid=3&url='.$_SERVER['HTTP_HOST']);
        $Data = json_decode($Auth_Url,true);
        if ($Data['code'] == 1){
            nathan_json('1',$Data['msg']);
        }else{
            nathan_json('0',$Data['msg']);
        }
        break;
    default:
        nathan_json('0','No Act');
        break;
}