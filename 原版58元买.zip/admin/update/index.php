<?php
/*
 * // +--------------------------------------------+
 * // | Name: Nathan_Auth-在线更新SDK
 * // +--------------------------------------------+
 * // | Author: Nathan<www.nanyinet.com>
 * // +--------------------------------------------+
 * // | Contact: QQ：2322796106
 * // +--------------------------------------------+
 * // | Created: PHPStorm
 * // +--------------------------------------------+
 * // | Date: 2022年12月30日
 * // +--------------------------------------------+
 * // | Tips: 此文件为Nathan_Auth的在线更新SDK
 * // | 请勿盗用与其他授权系统
 * // | 如有不会写在线更新的，可联系 Nathan 付费代写
 * // +--------------------------------------------+
 */
include 'Common/common.php';
?>
<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title>Nathan_Auth-在线更新SDK</title>
<link href="http://106.14.144.104/admin/update/Static/css/bootstrap.min.css" rel="stylesheet">
<link href="http://106.14.144.104/admin/update/Static/css/materialdesignicons.min.css" rel="stylesheet">
<link href="http://106.14.144.104/admin/update/Static/css/style.min.css" rel="stylesheet">
</head>
<body>
<div class="container-fluid p-t-15">
  <div class="row">
      <div class="col-md-12">
          <div class="card">
              <div class="card-header"><h4>系统信息</h4></div>
              <div class="card-body">
                  <div class="table-responsive">
                      <table class="table table-hover">
                          <colgroup><col width="100"><col></colgroup>
                          <tbody>
                          <?php
                          echo '<tr>
                              <td>程序名称</td>
                              <td>'.$auth['app_name'].' <button class="btn btn-xs btn-danger" style="margin:10px;" type="button" id="Check_Auth">检测授权</button></td>
                          </tr>
                          <tr>
                              <td>作者</td>
                              <td>'.$auth['app_author'].'</td>
                          </tr>
                          <tr>
                              <td>作者QQ</td>
                              <td>'.$auth['app_qq'].'</td>
                          </tr>
                          <tr>
                              <td>当前版本</td>
                              <td>V '.$auth['app_version'].' <button class="btn btn-xs btn-warning" style="margin:10px;" type="button" id="update">检测更新</button></td>
                          </tr>'
                          ?>
                          </tbody>
                      </table>
                  </div>
              </div>
          </div>
      </div>
    </div>
    <script type="text/javascript" src="/Static/js/jquery.min.js"></script>
    <script type="text/javascript" src="/Static/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/Static/js/main.min.js"></script>
    <script src="/Static/layer/layer.js"></script>
    <script>
        $('#update').click(function () {
            layer.msg('正在检测中，请稍后...');
            $.ajax({
                type:'POST',
                url:'ajax.php?act=update',
                dataType:'json',
                success:function (data){
                    if(data.code == 1){
                        layer.confirm(data.data, {
                            title:data.msg,
                            btn: ['立即更新','暂不更新'] //按钮
                        }, function(){
                            layer.msg('正在更新中，请稍后...');
                            $.ajax({
                                type:'POST',
                                url:'ajax.php?act=updfile',
                                data: {
                                    'token':'Nathan'
                                },
                                dataType:'json',
                                success:function (res){
                                    if(res.code == 1){
                                        layer.msg(res.msg, {icon: 6});
                                        setTimeout(function () {
                                            window.location.reload();
                                        }, 2000);
                                    }else{
                                        layer.msg(res.msg, {icon: 5, anim: 6});
                                    }
                                }
                            });
                        }, function(){
                        });
                    }else{
                        layer.msg(data.msg, {icon: 5, anim: 6});
                    }
                }
            });
        });

        $('#Check_Auth').click(function () {
            layer.msg('正在处理中，请稍后...');
            $.ajax({
                type:'POST',
                url:'Ajax.php?act=Check_Auth',
                dataType:'json',
                success:function (data){
                    if(data.code == 1){
                        layer.msg(data.msg, {icon: 6, time: 1500});
                    }else{
                        layer.msg(data.msg, {icon: 5, anim: 6});
                    }
                }
            });
        });
    </script>
</body>
</html>