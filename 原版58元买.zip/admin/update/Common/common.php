<?php
/*
 * // +--------------------------------------------+
 * // | Name: Nathan_Auth-在线更新SDK
 * // +--------------------------------------------+
 * // | Author: Nathan<www.nanyinet.com>
 * // +--------------------------------------------+
 * // | Contact: QQ：2322796106
 * // +--------------------------------------------+
 * // | Created: PHPStorm
 * // +--------------------------------------------+
 * // | Date: 2022年12月30日
 * // +--------------------------------------------+
 * // | Tips: 此文件为Nathan_Auth的在线更新SDK
 * // | 请勿盗用与其他授权系统
 * // | 如有不会写在线更新的，可联系 Nathan 付费代写
 * // +--------------------------------------------+
 */
 
error_reporting(0);
session_start();
define('IN_CRONLITE', true);
define('SYSTEM_ROOT', dirname(__FILE__).'/');
define('ROOT', dirname(SYSTEM_ROOT).'/');

$dbconfig = array(
    'host' => 'localhost', //数据库服务器
    'port' => 3306, //数据库端口
    'username' => 'demo', //数据库用户名
    'password' => 'cbnF2iKH3i3fjZdH', //数据库密码
    'dbname' => 'demo' //数据库名
);

include_once(SYSTEM_ROOT . 'Db.php');
$link = mysqli_connect($dbconfig['host'], $dbconfig['username'], $dbconfig['password'], $dbconfig['dbname'], $dbconfig['port']);
if (!$link) {
    exit(json_encode(['code' => 0, 'msg' => '数据库链接失败！原因：'.mysqli_connect_error()]));
}
$DB = new Db($dbconfig['host'],$dbconfig['username'],$dbconfig['password'],$dbconfig['dbname'],$dbconfig['port']);
$auth = require_once 'Auth.php';

function getCurl($url, $post = null, &$header = null) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    curl_setopt($ch, CURLOPT_USERAGENT, 'Chrome 42.0.2311.135');
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    // 返回response头部信息
    curl_setopt($ch, CURLOPT_HEADER, 1);
    $ret = curl_exec($ch);
    $err = curl_error($ch);

    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $header = substr($ret, 0, $headerSize);
    $ret = substr($ret, $headerSize);

    curl_close($ch);

    // var_dump($header, $ret);
    // echo PHP_EOL, PHP_EOL, PHP_EOL;

    if ($err) {
        return [false, $err];
    } else {
        return [true, $ret];
    }
}

function nathan_json($code, $msg = NULL,$data = NULL) {
    $jsonData = array(
        'code' => $code,
        'msg' => $msg,
        'data' => $data,
    );
    exit(json_encode($jsonData));
}
function curl_request($url, $post = '', $referer = '', $cookie = '', $returnCookie = 0, $ua = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:43.0) Gecko/20100101 Firefox/43.0') {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_USERAGENT, $ua);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($curl, CURLOPT_AUTOREFERER, 1);
    curl_setopt($curl, CURLOPT_TIMEOUT, 60);
    curl_setopt($curl, CURLOPT_REFERER, $referer);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    $httpheader[] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8";
    $httpheader[] = "Accept-Encoding:gzip, deflate";
    $httpheader[] = "Accept-Language:zh-CN,zh;q=0.9";
    $httpheader[] = "Connection:close";
    curl_setopt($curl, CURLOPT_HTTPHEADER, $httpheader);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    if ($post) {
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post));
    }
    if ($cookie) {
        curl_setopt($curl, CURLOPT_COOKIE, $cookie);
    }
    curl_setopt($curl, CURLOPT_HEADER, $returnCookie);
    curl_setopt($curl, CURLOPT_TIMEOUT, 10);
    curl_setopt($curl, CURLOPT_ENCODING, "gzip");
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($curl);
    if (curl_errno($curl)) {
        return curl_error($curl);
    }
    curl_close($curl);
    if ($returnCookie) {
        list($header, $body) = explode("\r\n\r\n", $data, 2);
        preg_match_all("/Set\-Cookie:([^;]*);/", $header, $matches);
        $info['cookie'] = substr($matches[1][1], 1);
        $info['content'] = $body;
        return $info;
    } else {
        return $data;
    }
}
function delete_dir_file($dir_name) {
    $result = false;
    if (is_dir($dir_name)) {
        if ($handle = opendir($dir_name)) {
            while (false !== ($item = readdir($handle))) {
                if ($item != '.' && $item != '..') {
                    if (is_dir($dir_name . '/' . $item)) {
                        delete_dir_file($dir_name . '/' . $item);
                    } else {
                        unlink($dir_name . '/' . $item);
                    }
                }
            }
            closedir($handle);
            if (rmdir($dir_name)) {
                $result = true;
            }
        }
    }
    return $result;
}